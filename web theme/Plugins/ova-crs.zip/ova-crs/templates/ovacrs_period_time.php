<div class="ovacrs_petime">
	<table class="widefat">

		<thead>
			<tr>
				<th><?php esc_html_e( 'ID*', 'ova-crs' ); ?></th>
				<th><?php esc_html_e( 'Price*', 'ova-crs' ); ?></th>
				<th><?php esc_html_e( 'Package Type*', 'ova-crs' ); ?></th>
				<th><?php esc_html_e( 'Package*', 'ova-crs' ); ?></th>
				<th><?php esc_html_e( 'Discount', 'ova-crs' ); ?></th>
			</tr>
		</thead>

		<tbody class="wrap_petime">
			<!-- Append html here -->
			<?php if( $ovacrs_petime_id = get_post_meta( $post_id, 'ovacrs_petime_id', true ) ){
				
				$ovacrs_petime_price = get_post_meta( $post_id, 'ovacrs_petime_price', true );
				$ovacrs_petime_days = get_post_meta( $post_id, 'ovacrs_petime_days', true );
				$ovacrs_petime_label = get_post_meta( $post_id, 'ovacrs_petime_label', true );
				$ovacrs_petime_discount = get_post_meta( $post_id, 'ovacrs_petime_discount', true );
				$ovacrs_package_type = get_post_meta( $post_id, 'ovacrs_package_type', true );

				$ovacrs_pehour_start_time = get_post_meta( $post_id, 'ovacrs_pehour_start_time', true );
				$ovacrs_pehour_end_time = get_post_meta( $post_id, 'ovacrs_pehour_end_time', true );
				
				$ovacrs_pehour_unfixed = get_post_meta( $post_id, 'ovacrs_pehour_unfixed', true );

				for( $i = 0 ; $i < count( $ovacrs_petime_id ); $i++ ) {
					
			?>

				<tr class="row_petime_record" data-pos="<?php echo esc_attr($i); ?>">

				    <td width="10%">
				        <input type="text" placeholder="<?php esc_html_e('not space', 'ova-crs'); ?>" name="ovacrs_petime_id[]" value="<?php echo esc_attr($ovacrs_petime_id[$i]); ?>" class="ovacrs_petime_id" >
				    </td>

				    <td width="10%">
				        <input type="text"  placeholder="<?php esc_html_e('Price', 'ova-crs'); ?>" name="ovacrs_petime_price[]" value="<?php echo esc_attr($ovacrs_petime_price[$i]); ?>"  class="ovacrs_petime_price"/>
				    </td>

				    <td width="25%">
				    	<div class="clearfix">

				    		<select name="ovacrs_package_type[]" class="ovacrs_package_type">
				    			<option value="inday" <?php echo  ( isset( $ovacrs_package_type[$i] ) &&  $ovacrs_package_type[$i] == 'inday' ) ? 'selected' : ''; ?> >
				    				<?php esc_html_e( 'Period of Fixed Hours in day', 'ova-crs' ); ?>
				    			</option>
				    			<option value="other" <?php echo ( isset( $ovacrs_package_type[$i] ) && $ovacrs_package_type[$i] == 'other' ) ? 'selected' : ''; ?>>
				    				<?php esc_html_e( 'Period of Fixed Days', 'ova-crs' ); ?>
				    			</option>
				    		</select>

				    	</div>
				    	
				        <input type="number"  placeholder="<?php esc_html_e('Total Day', 'ova-crs'); ?>" name="ovacrs_petime_days[]" value="<?php echo esc_attr($ovacrs_petime_days[$i]); ?>"  class="ovacrs_petime_days"/>
				       
				        <div class="period_times">
				        	
				        	<input type="text"  placeholder="<?php esc_html_e('Start Hour', 'ova-crs'); ?>" name="ovacrs_pehour_start_time[]" value="<?php echo esc_attr($ovacrs_pehour_start_time[$i]); ?>"  class="ovacrs_pehour_start_time ovacrs_pehour_picker" autocomplete="off"/>

				        	 <input type="text"  placeholder="<?php esc_html_e('End Hour', 'ova-crs'); ?>" name="ovacrs_pehour_end_time[]" value="<?php echo esc_attr($ovacrs_pehour_end_time[$i]); ?>"  class="ovacrs_pehour_end_time ovacrs_pehour_picker" autocomplete="off"/>

				        </div>

				        <div class="period_times_unfixed">
				        	<input type="text"  placeholder="<?php esc_html_e('Total Hour', 'ova-crs'); ?>" name="ovacrs_pehour_unfixed[]" value="<?php echo esc_attr($ovacrs_pehour_unfixed[$i]); ?>"  autocomplete="off"/>
				        </div>

				    </td>

				    <td width="10%">
				      <input type="text" placeholder="<?php esc_html_e( 'Text', 'ova-crs' ); ?>" name="ovacrs_petime_label[]" value="<?php echo esc_attr($ovacrs_petime_label[$i]); ?>" class="ovacrs_petime_label ">
				    </td>

				    <td width="24%" class="ovacrs_petime_dis">
				    	<table width="100%" class="ovacrs_petime_discount">

					      	<thead>
								<tr>
									<th><?php esc_html_e( 'Price ($)', 'ova-crs' ); ?></th>
									<th><?php esc_html_e( 'Start Time', 'ova-crs' ); ?></th>
									<th><?php esc_html_e( 'End Time', 'ova-crs' ); ?></th>
								</tr>
							</thead>

							<tbody class="real">

								<?php if( isset( $ovacrs_petime_discount[$i]['price'] ) ){ ?>
								<?php for( $k = 0; $k < count( $ovacrs_petime_discount[$i]['price'] ); $k++ ){ ?>
									<tr class="tr_petime_discount">
																
										<td width="30%">
										    <input type="text" class="ovacrs_petime_discount_price " placeholder="<?php esc_html_e('Price', 'ova-crs') ?>" 
										    	name="ovacrs_petime_discount[<?php echo $i;?>][price][]" value="<?php echo esc_attr( $ovacrs_petime_discount[$i]['price'][$k] ); ?>" />
										</td>
										<td width="30%">
										    <input type="text" class="ovacrs_petime_discount_start_time datetimepicker" placeholder="<?php esc_html_e('Start Time', 'ova-crs') ?>" 
										    	name="ovacrs_petime_discount[<?php echo $i;?>][start_time][]" value="<?php echo esc_attr( $ovacrs_petime_discount[$i]['start_time'][$k] ); ?>" />
										</td>
										<td width="30%">
										    <input type="text" class="ovacrs_petime_discount_end_time datetimepicker" placeholder="<?php esc_html_e('End Time', 'ova-crs') ?>" 
										    	name="ovacrs_petime_discount[<?php echo $i;?>][end_time][]" value="<?php echo esc_attr( $ovacrs_petime_discount[$i]['end_time'][$k] ); ?>" />
										</td>

										
									<td width="9%"><a href="#" class="delete_petime_discount">x</a></td>

									</tr> 
									
								<?php } }?>
							
								
							</tbody>

							<tfoot>
								<tr>
									<th colspan="6">
										<a href="#" class="button insert_petime_discount">
											<?php esc_html_e( 'Add Discount', 'ova-crs' ); ?>
											<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_petime_discount.php' ); ?>
										</a>
									</th>
								</tr>
							</tfoot>

				      	
				      	</table>
				    </td>


				    <td width="1%"><a href="#" class="delete_petime">x</a></td>
				</tr>
			<?php } } ?>
		</tbody>

		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_petime_record" data-row="
						<?php
							ob_start();
							include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_petime_record.php' );
							echo esc_attr( ob_get_clean() );
						?>

					">
					<?php esc_html_e( 'Add Period Time', 'ova-crs' ); ?></a>
					</a>

					
				</th>
			</tr>
		</tfoot>

	</table>
</div>


