<tr class="tr_rt_feature">

    <td width="20%">
      <input type="text" name="ovacrs_features_icons[]" placeholder="<?php esc_html_e( 'Font-Awesome', 'ova-crs' ); ?>" value="" />
    </td>

    <td width="20%">
      <input type="text" name="ovacrs_features_label[]" placeholder="<?php esc_html_e( 'Label', 'ova-crs' ); ?>" value="" />
    </td>

    <td width="29%">
      <input type="text" name="ovacrs_features_desc[]" placeholder="<?php esc_html_e( 'Description', 'ova-crs' ); ?>" value="" />
    </td>

    <td width="20%">
      <select  name="ovacrs_features_special[]" class="short_dura">
    		<option value="yes" ><?php esc_html_e( 'Yes', 'ova-crs' ); ?></option>
    		<option value="no"  ><?php esc_html_e( 'No', 'ova-crs' ); ?></option>
    	</select>
    </td>

    <td width="1%"><a href="#" class="delete_feature">x</a></td>
    
</tr>