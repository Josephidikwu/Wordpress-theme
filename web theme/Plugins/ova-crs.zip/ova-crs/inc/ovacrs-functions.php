<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if( !function_exists( 'ovacrs_locate_template' ) ){
	function ovacrs_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacrs-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovacrs-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVACRS_PLUGIN_PATH . 'ovacrs-templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// ,$template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovacrs_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovacrs_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovacrs_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	
	include $template_file;
}

function ovacrs_woo_wp_select_multiple( $field ) {
    global $thepostid, $post, $woocommerce;

    $thepostid              = empty( $thepostid ) ? $post->ID : $thepostid;
    $field['class']         = isset( $field['class'] ) ? $field['class'] : 'select short';
    $field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';
    $field['name']          = isset( $field['name'] ) ? $field['name'] : $field['id'];
    $field['value']         = isset( $field['value'] ) ? $field['value'] : ( get_post_meta( $thepostid, $field['id'], true ) ? get_post_meta( $thepostid, $field['id'], true ) : array() );

    echo '<p class="form-field ' . esc_attr( $field['id'] ) . '_field ' . esc_attr( $field['wrapper_class'] ) . '"><label for="' . esc_attr( $field['id'] ) . '">' . wp_kses_post( $field['label'] ) . '</label><select id="' . esc_attr( $field['id'] ) . '" name="' . esc_attr( $field['name'] ) . '" class="' . esc_attr( $field['class'] ) . '" multiple="multiple">';

    foreach ( $field['options'] as $key => $value ) {

        echo '<option value="' . esc_attr( $key ) . '" ' . ( in_array( $key, $field['value'] ) ? 'selected="selected"' : '' ) . '>' . esc_html( $value ) . '</option>';

    }

    echo '</select> ';

    if ( ! empty( $field['description'] ) ) {

        if ( isset( $field['desc_tip'] ) && false !== $field['desc_tip'] ) {
            echo '<img class="help_tip" data-tip="' . esc_attr( $field['description'] ) . '" src="' . esc_url( WC()->plugin_url() ) . '/assets/images/help.png" height="16" width="16" />';
        } else {
            echo '<span class="description">' . wp_kses_post( $field['description'] ) . '</span>';
        }

    }
    echo '</p>';
}

if( ! function_exists( 'ovacrs_get_list_field_checkout' ) ) {
	function ovacrs_get_list_field_checkout( $post_id ) {
		if( ! $post_id ) return [];
		$ovacrs_manage_custom_checkout_field = get_post_meta( $post_id, 'ovacrs_manage_custom_checkout_field', true );
		$list_field_checkout = get_option( 'ovacrs_booking_form', array() );
		$list_field_checkout_in_product = get_post_meta( $post_id, 'ovacrs_product_custom_checkout_field', true );
		$list_field_checkout_in_product_arr = explode( ',', $list_field_checkout_in_product );
		$list_field_checkout_in_product_arr = array_map( 'trim', $list_field_checkout_in_product_arr );


		if( $ovacrs_manage_custom_checkout_field === 'new' ) {
			$list_ckf_output = [];
			if( ! empty( $list_field_checkout_in_product_arr ) && is_array( $list_field_checkout_in_product_arr ) ) {
				foreach( $list_field_checkout_in_product_arr as $field_name ) {
					if( array_key_exists( $field_name, $list_field_checkout ) ) {
						$list_ckf_output[$field_name] = $list_field_checkout[$field_name];
					}
				}
			} 
		} else {
			$list_ckf_output = $list_field_checkout;
		}
		return $list_ckf_output;
	}
}

if( !function_exists('ovacrs_order_status') ){
	function ovacrs_order_status(){
		return apply_filters( 'ovacrs_order_status', array( 'wc-completed', 'wc-processing' ) );		
	}
}

// Get Array Product ID with WPML
function get_arr_product_ids( $product_id_original ){

	$translated_ids = Array();

	// get plugin active
	$active_plugins = get_option('active_plugins');

	if ( in_array ( 'polylang/polylang.php', $active_plugins ) || in_array ( 'polylang-pro/polylang.php', $active_plugins ) ) {
			$languages = pll_languages_list();
			if ( !isset( $languages ) ) return;
			foreach ($languages as $lang) {
				$translated_ids[] = pll_get_post($product_id_original, $lang);
			}
	} elseif ( in_array ( 'sitepress-multilingual-cms/sitepress.php', $active_plugins ) ) {
		global $sitepress;
	
		if(!isset($sitepress)) return;
		
		$trid = $sitepress->get_element_trid($product_id_original, 'post_product');
		$translations = $sitepress->get_element_translations($trid, 'product');
		foreach( $translations as $lang=>$translation){
		    $translated_ids[] = $translation->element_id;
		}

	} else {
		$translated_ids[] = $product_id_original;
	}

	return apply_filters( 'ovacrs_multiple_languages', $translated_ids );  

}


// Add javascript to wp head
add_action('admin_head', 'ovacrs_hook_javascript');
add_action('wp_head', 'ovacrs_hook_javascript');
function ovacrs_hook_javascript() {
	$dayOfWeekStart = apply_filters( 'ovacres_calendar_dayofweekstart', 1 );
    ?>
        <script type="text/javascript">
            var dayOfWeekStart = <?php echo $dayOfWeekStart; ?>;
        </script>
    <?php
}




