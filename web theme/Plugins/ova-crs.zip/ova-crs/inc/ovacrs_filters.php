<?php if ( !defined( 'ABSPATH' ) ) exit();

/* Change at frontend */
add_filter( 'woocommerce_display_item_meta', 'ovacrs_filter_woocommerce_display_item_meta', 10, 3 ); 
function ovacrs_filter_woocommerce_display_item_meta( $html, $item, $args ) { 

    $html = str_replace('ovacrs_pickup_loc', esc_html__(' Pick-up Location ', 'ova-crs') , $html );
    $html = str_replace('ovacrs_pickoff_loc', esc_html__(' Drop-off Location ', 'ova-crs') , $html );
    $html = str_replace('ovacrs_pickup_date', esc_html__(' Pick-up date ', 'ova-crs') , $html );
    $html = str_replace('ovacrs_pickoff_date', esc_html__(' Drop-off date ', 'ova-crs') , $html );
    $html = str_replace('ovacrs_total_days', esc_html__(' Total Time ', 'ova-crs') , $html );
    $html = str_replace('ovacrs_price_detail', esc_html__(' Price Detail ', 'ova-crs') , $html );
    $html = str_replace('rental_type', esc_html__(' Rental Type', 'ova-crs') , $html );
    $html = str_replace('period_label', esc_html__(' Package', 'ova-crs') , $html );
    $html = str_replace('package_type', esc_html__(' Package Type', 'ova-crs') , $html );
    $html = str_replace('ovacrs_quantity', esc_html__(' Quantity', 'ova-crs') , $html );
    
    
    return $html;
}; 


/* Hide Rental Type, Price Detail at Frontend */
if( !is_admin() ){ add_filter( 'woocommerce_order_item_get_formatted_meta_data', 'change_formatted_meta_data', 20, 2 ); }
function change_formatted_meta_data( $meta_data, $item ) {
    $new_meta = array();
    foreach ( $meta_data as $id => $meta_array ) {
        // We are removing the meta with the key 'something' from the whole array.
        if ( 'rental_type' === $meta_array->key || 'ovacrs_price_detail' === $meta_array->key || 'package_type' === $meta_array->key ) { continue; }
        $new_meta[ $id ] = $meta_array;
    }
    return $new_meta;
}




function ovacrs_text_time( $price_type, $rent_time ){
	if( $price_type == 'day' ){
		$text = esc_html__( 'Day(s)', 'ova-crs' );
	}else if( $price_type == 'hour' ){
		$text = esc_html__( 'Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] < 1){
		$text = esc_html__( 'Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] >= 1){
		$text = esc_html__( 'Day(s)', 'ova-crs' );
	}else{
        $text = '';
    }
    return $text;
}

function ovacrs_text_time_gl( $price_type, $rent_time ){
	if( $price_type == 'day' ){
		$text = esc_html__( 'Regular Day(s)', 'ova-crs' );
	}else if( $price_type == 'hour' ){
		$text = esc_html__( 'Regular Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] < 1){
		$text = esc_html__( 'Regular Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] >= 1){
		$text = esc_html__( 'Regular Day(s)', 'ova-crs' );
	}else{
        $text = '';
    }
    return $text;
}

function ovacrs_text_time_rt( $price_type, $rent_time ){
	if( $price_type == 'day' ){
		$text = esc_html__( 'Special Day(s)', 'ova-crs' );
	}else if( $price_type == 'hour' ){
		$text = esc_html__( 'Special Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] < 1){
		$text = esc_html__( 'Special Hour(s)', 'ova-crs' );
	}else if( $price_type == 'mixed' && $rent_time['rent_time_day_raw'] >= 1){
		$text = esc_html__( 'Special Day(s)', 'ova-crs' );
	}else{
        $text = '';
    }
    return $text;
}



// Get Real Quantity 
function get_real_quantity( $product_quantity, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date  ){

    $rent_time = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );
    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    /* Global */
    $gl_quantity = ovacrs_quantity_global( $product_id, $rent_time );

    // Display for case: PickUp/PickOff in Special Time
    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_enddate = get_post_meta( $product_id, 'ovacrs_rt_enddate', true );

    //add
    $gl_quantity_total = ovacrs_quantity_global( $product_id, $rent_time );
    
    $quantity_hour = 0;
   
    $hour_total_text = '';
    if ($price_type === "mixed") {

        $gl_quantity_total = floor($rent_time['rent_time_day_raw']);

        if( $rent_time['rent_time_day_raw'] < 1 ){
            $gl_quantity_total = (int)$rent_time['rent_time_hour'];
        }

        if ($gl_quantity_total <= 0) { 
            $quantity_hour = $rent_time['rent_time_hour_raw'];
        } elseif ($gl_quantity_total > 0) {
            $quantity_hour = ($rent_time['rent_time_hour_raw'] - $gl_quantity_total * 24);
        }

        if( $quantity_hour > 0 ) {
            $hour_total_text = $quantity_hour . esc_html__( ' Regular Hour(s)', 'ova-crs' );
        }

    }


    $i = 0; $data_max; $flag_max = false;
    $product_quantity = '';
    $product_quantity_regular = '';
    $rt_quantity_total = 0;

    if( $ovacrs_rt_startdate ){
        foreach ($ovacrs_rt_startdate as $key_rt => $value_rt) {

            $start_date_str = $ovacrs_rt_startdate[$key_rt];
            $end_date_str = $ovacrs_rt_enddate[$key_rt];

            $i++;

            if( $i === 1 ) {
                $data_max = strtotime( $end_date_str );
                $flag_max = true;
            } elseif( $data_max < strtotime( $end_date_str ) ) {

                $data_max = strtotime( $end_date_str );
                $flag_max = true;
            } else {
                $flag_max = false;
            }

           


                // If Special_Time_Start_Date <= pickup_date && pickoff_date <= Special_Time_End_Date
            if( $ovacrs_pickup_date >= strtotime( $start_date_str ) && $ovacrs_pickoff_date <= strtotime( $end_date_str ) ){

                $rt_quantity = ovacrs_quantity_global( $product_id, $rent_time );
                $product_quantity = $rt_quantity.' '.ovacrs_text_time_rt( $price_type, $rent_time );

                $rt_quantity_total = $gl_quantity_total;

                if( $flag_max && $quantity_hour > 0 ) {
                    $hour_total_text = $quantity_hour . esc_html__( ' Special Hour(s)', 'ova-crs' );
                }

            }elseif( $ovacrs_pickup_date < strtotime( $start_date_str ) && $ovacrs_pickoff_date <= strtotime( $end_date_str ) && $ovacrs_pickoff_date >= strtotime( $start_date_str ) ){

                $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $start_date_str ) );
                $gl_quantity = ovacrs_quantity_global( $product_id, $gl_quantity_array );

                $rt_quantity_array = get_time_bew_2day( strtotime( $start_date_str ), $ovacrs_pickoff_date );

                
                if( $price_type == 'mixed' ) {
                    $rt_quantity = floor( $rt_quantity_array['rent_time_day_raw'] );
                } elseif( $price_type == 'hour' ) {
                     $rt_quantity = (int)$rt_quantity_array['rent_time_hour'];
                } else {
                    $rt_quantity = (int)$rt_quantity_array['rent_time_day'];
                }

                $rt_quantity_total += $rt_quantity;

                $product_quantity .= $rt_quantity.' '.ovacrs_text_time_rt( $price_type , $rent_time) . '<br/>';
                
                if( $flag_max && $quantity_hour > 0 ) {
                    $hour_total_text = $quantity_hour . esc_html__( ' Special Hour(s)', 'ova-crs' );
                }

            }else if( $ovacrs_pickup_date >= strtotime( $start_date_str ) && $ovacrs_pickup_date <= strtotime( $end_date_str ) && $ovacrs_pickoff_date >= strtotime( $end_date_str ) ){

                $rt_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $end_date_str ) );
                

                if( $price_type == 'mixed' ) {
                    $rt_quantity = floor( $rt_quantity_array['rent_time_day_raw'] );
                } elseif( $price_type == 'hour' ) {
                     $rt_quantity = (int)$rt_quantity_array['rent_time_hour'];
                } else {
                    $rt_quantity = (int)$rt_quantity_array['rent_time_day'];
                }

                $gl_quantity_array = get_time_bew_2day( strtotime( $end_date_str ), $ovacrs_pickoff_date );
                $gl_quantity = ovacrs_quantity_global( $product_id, $gl_quantity_array );

                $rt_quantity_total += $rt_quantity;

                $product_quantity .= $rt_quantity.' '.ovacrs_text_time_rt( $price_type, $rent_time ) .'<br/> ';



            }else if( $ovacrs_pickup_date < strtotime( $start_date_str ) && $ovacrs_pickoff_date > strtotime( $end_date_str ) ){

                    // Time section 1
                $gl_rent_time_1 = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $start_date_str ) );
                $gl_quantity_1 = ovacrs_quantity_global( $product_id, $gl_rent_time_1 );

                $gl_rent_time_3 = get_time_bew_2day( strtotime( $end_date_str ), $ovacrs_pickoff_date );
                $gl_quantity_3 = ovacrs_quantity_global( $product_id, $gl_rent_time_3 );

                $rt_rent_time_2 = get_time_bew_2day( strtotime( $start_date_str ), strtotime( $end_date_str ) );
                

                if( $price_type == 'mixed' ) {
                    $rt_quantity_2 = floor( $rt_rent_time_2['rent_time_day_raw'] );
                } elseif( $price_type == 'hour' ) {
                     $rt_quantity_2 = (int)$rt_rent_time_2['rent_time_hour'];
                } else {
                    $rt_quantity_2 = (int)$rt_rent_time_2['rent_time_day'];
                }

                $rt_quantity_total += $rt_quantity_2;

                $gl_quantity = $gl_quantity_1 + $gl_quantity_3;

                $product_quantity .= $rt_quantity_2.' '.ovacrs_text_time_rt( $price_type, $rent_time ).'<br/> ';
 

            }

        }
    }

    $gl_quantity = $gl_quantity_total - $rt_quantity_total;

    if( $gl_quantity > 0 ) {
        $product_quantity .= $gl_quantity.' '.ovacrs_text_time_gl( $price_type , $rent_time);
    }

    if( $hour_total_text ) {
        if( $product_quantity ) {
            $product_quantity .= '<br>' . $hour_total_text;
        } else {
            $product_quantity .= $hour_total_text;
        }
        
    }

    return $product_quantity; 
}


// Get Real Price
function get_real_price( $product_price, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ){

    $rent_time = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );
    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_enddate = get_post_meta( $product_id, 'ovacrs_rt_enddate', true );


        // Global
    $gl_price = ovacrs_price_global( $product_id, $rent_time );
    $product_price = wc_price( $gl_price );

    $product_price = '';

    $flag_all_rt = false;

    if( $ovacrs_rt_startdate ){
        foreach ($ovacrs_rt_startdate as $key_rt => $value_rt) {

                // If Special_Time_Start_Date <= pickup_date && pickoff_date <= Special_Time_End_Date
            if( $ovacrs_pickup_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                $rt_price = ovacrs_price_special_time( $product_id, $rent_time, $key_rt );

                $product_price .= wc_price( $rt_price ).'/'.ovacrs_text_time_rt( $price_type, $rent_time );

                $flag_all_rt = true;

                // break;
                
            }else if( $ovacrs_pickup_date < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $ovacrs_pickoff_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) ){


                $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );

                $rt_quantity_array = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), $ovacrs_pickoff_date );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );

                $product_price .= wc_price( $rt_price ).'/'.ovacrs_text_time_rt( $price_type, $rent_time ).'<br/>';

                // break;


            }else if( $ovacrs_pickup_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickup_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $ovacrs_pickoff_date >= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){


                $rt_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_enddate[$key_rt] ) );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );


                $gl_quantity_array = get_time_bew_2day( strtotime( $ovacrs_rt_enddate[$key_rt] ), $ovacrs_pickoff_date );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );


                $product_price .= wc_price( $rt_price ).'/'.ovacrs_text_time_rt( $price_type, $rent_time ).'<br>';

                // break;

            }else if( $ovacrs_pickup_date < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date > strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                    // Time section 1
                $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );


                $rent_time_2 = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), strtotime( $ovacrs_rt_enddate[$key_rt] ) );
                $rt_price = ovacrs_price_special_time( $product_id, $rent_time_2, $key_rt );

                $product_price .= wc_price( $rt_price ).'/'.ovacrs_text_time_rt( $price_type, $rent_time ).'<br/>';

                // break;

            }

        }
    }


    if( $product_price === '' ) {
        $product_price = wc_price( $gl_price );
    } elseif( $flag_all_rt ){
        $product_price = $product_price;
    } else {
        $product_price .= wc_price( $gl_price ).'/'.ovacrs_text_time_gl( $price_type, $rent_time );
    }

    
    

    return $product_price; 
}




// Filter Quantity for Cart

add_filter( 'woocommerce_widget_cart_item_quantity', 'ovacrs_woocommerce_widget_cart_item_quantity', 10, 3 );
function ovacrs_woocommerce_widget_cart_item_quantity( $product_quantity,  $cart_item, $cart_item_key ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){

        if( isset( $cart_item['rental_type'] ) && ( $cart_item['rental_type'] == 'period_time' || $cart_item['rental_type'] == 'period_hour' ) ){

            return '× 1';
        }else{
            $product_id = $cart_item['product_id'];
            $ovacrs_pickup_date = strtotime( $cart_item['ovacrs_pickup_date'] );
            $ovacrs_pickoff_date = strtotime( $cart_item['ovacrs_pickoff_date'] );

            return '× '.get_real_quantity( $product_quantity, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date );         
        }
        

    }else{

        return $product_quantity;

    }
    
}; 


add_filter( 'woocommerce_cart_item_quantity', 'ovacrs_filter_woocommerce_cart_item_quantity', 10, 3 ); 
function ovacrs_filter_woocommerce_cart_item_quantity( $product_quantity, $cart_item_key, $cart_item ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){

        $product_id = $cart_item['product_id'];
        $ovacrs_price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

        if( isset( $cart_item['rental_type'] ) && ( $cart_item['rental_type'] == 'period_time' || $cart_item['rental_type'] == 'period_hour' ) ){
            return $cart_item['ovacrs_quantity'];
        }else{
            $product_id = $cart_item['product_id'];
            $ovacrs_pickup_date = strtotime( $cart_item['ovacrs_pickup_date'] );
            $ovacrs_pickoff_date = strtotime( $cart_item['ovacrs_pickoff_date'] );

            if( $ovacrs_price_type === 'transportation' ) {
                return $cart_item['ovacrs_quantity'];
            } else {
                return  get_real_quantity( $product_quantity, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date );
            }

        }
        

    }else{

        return $product_quantity;

    }
    
}; 




// Filter Quantity for Checkout
add_filter( 'woocommerce_checkout_cart_item_quantity', 'ovacrs_woocommerce_checkout_cart_item_quantity', 10, 3 );
function ovacrs_woocommerce_checkout_cart_item_quantity( $product_quantity, $cart_item, $cart_item_key ){

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){

        if( isset( $cart_item['rental_type'] ) && ( $cart_item['rental_type'] == 'period_time' || $cart_item['rental_type'] == 'period_hour' ) ){
            return '<span class="ovacrs_qty">'.$cart_item['ovacrs_quantity'].'</span>';
        }else{
            $product_id = $cart_item['product_id'];
            $ovacrs_pickup_date = strtotime( $cart_item['ovacrs_pickup_date'] );
            $ovacrs_pickoff_date = strtotime( $cart_item['ovacrs_pickoff_date'] );

            return '<span class="ovacrs_qty">'.get_real_quantity( $product_quantity, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ).'</span>';    
        }
        

    }else{

        return $product_quantity;

    }

}



// Filter Price for Cart
add_filter( 'woocommerce_cart_item_price', 'ovacrs_filter_woocommerce_cart_item_price', 10, 3 ); 
function ovacrs_filter_woocommerce_cart_item_price( $product_price, $cart_item, $cart_item_key ) {

    if( $cart_item['data']->is_type('ovacrs_car_rental') ){

        $product_id = $cart_item['product_id'];
        $ovacrs_price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

        if( isset( $cart_item['rental_type'] ) && ( $cart_item['rental_type'] == 'period_time' || $cart_item['rental_type'] == 'period_hour' ) ){
            return wc_price( $cart_item['period_price'] );
        }else{
            $product_id = $cart_item['product_id'];
            $ovacrs_pickup_date = strtotime( $cart_item['ovacrs_pickup_date'] );
            $ovacrs_pickoff_date = strtotime( $cart_item['ovacrs_pickoff_date'] );   

            if( $ovacrs_price_type == 'transportation' ) {
                return wc_price( $cart_item['price_transport'] );
            } else {
                return get_real_price( $product_price, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date );
            }

        }     
        
    }else{
        return $product_price;
    }
    
}

// Filter Quantity for Order detail after checkout
add_filter( 'woocommerce_order_item_quantity_html', 'ovacrs_woocommerce_order_item_quantity_html', 10, 2 ); 
function ovacrs_woocommerce_order_item_quantity_html( $quantity, $item ){

    $product_id = $item->get_product_id();
    $product = wc_get_product( $product_id );

    $rental_type_period = false;
    $ovacrs_quantity = 1;

    if( $product->is_type( 'ovacrs_car_rental' ) ){

        foreach ( $item->get_formatted_meta_data() as $meta_id => $meta ) {
            if( $meta->key == 'ovacrs_pickup_date' ){
                $ovacrs_pickup_date = strtotime( $meta->value ) ;
            }
            if( $meta->key == 'ovacrs_pickoff_date' ){
                $ovacrs_pickoff_date = strtotime( $meta->value );
            }
            if( $meta->key == 'period_label' ){
                $rental_type_period = true;
            }
            if( $meta->key == 'ovacrs_quantity' ){
                $ovacrs_quantity = $meta->value;
            }
        }

        if( $rental_type_period ) {
            return '<span class="ovacrs_qty">'.$ovacrs_quantity.'</span>';        
        }else{
            return '<span class="ovacrs_qty">'.get_real_quantity( $quantity, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ).'</span>';        
        }
        
    }

    return $quantity;
    
}



/* Change Order at backend */
add_filter( 'woocommerce_order_item_display_meta_key', 'ovacrs_change_order_item_meta_title', 20, 3 );

/**
 * Changing a meta title
 * @param  string        $key  The meta key
 * @param  WC_Meta_Data  $meta The meta object
 * @param  WC_Order_Item $item The order item object
 * @return string        The title
 */
function ovacrs_change_order_item_meta_title( $key, $meta, $item ) {

    // By using $meta-key we are sure we have the correct one.
    if ( 'ovacrs_pickup_loc' === $meta->key ) { $key = esc_html__(' Pick-up Location ', 'ova-crs'); }
    if ( 'ovacrs_pickoff_loc' === $meta->key ) { $key = esc_html__(' Drop-off Location ', 'ova-crs'); }
    if ( 'ovacrs_pickup_date' === $meta->key ) { $key = esc_html__(' Pick-up date ', 'ova-crs'); }
    if ( 'ovacrs_pickoff_date' === $meta->key ) { $key = esc_html__(' Drop-off date ', 'ova-crs'); }
    if ( 'ovacrs_total_days' === $meta->key ) { $key = esc_html__(' Total Time ', 'ova-crs'); }
    if ( 'ovacrs_price_detail' === $meta->key ) { $key = esc_html__(' Price Detail ', 'ova-crs'); }
    if ( 'id_vehicle' === $meta->key ) { $key = esc_html__(' ID Vehicle ', 'ova-crs'); }
    if ( 'ovacrs_amount_insurance_product' === $meta->key ) { $key =esc_html__( 'Amount Of Insurance', 'ova-crs' ); }
    if ( 'ovacrs_location_fee' === $meta->key ) { $key =esc_html__( 'Location Fee', 'ova-crs' ); }
    if ( 'ovacrs_deposit_amount_product' === $meta->key ) { $key =esc_html__( 'Deposit Amount', 'ova-crs' ); }
    if ( 'ovacrs_remaining_amount_product' === $meta->key ) { $key =esc_html__( 'Remaining Amount', 'ova-crs' ); }

    if ( 'rental_type' === $meta->key ) { $key = esc_html__(' Rental Type ', 'ova-crs'); }
    if ( 'period_label' === $meta->key ) { $key = esc_html__(' Package ', 'ova-crs'); }
    if ( 'package_type' === $meta->key ) { $key = esc_html__(' Package Type ', 'ova-crs'); }
    if ( 'ovacrs_quantity' === $meta->key ) { $key = esc_html__(' Quantity ', 'ova-crs'); }

    

    $list_fields = get_option( 'ovacrs_booking_form', array() );

    if( is_array( $list_fields ) && ! empty( $list_fields ) ) {
        foreach( $list_fields as $key_field => $field ) {

            if( $key_field === $meta->key ) {
                $key = $field['label'];
            }
        }
    }
    
    

    return $key;
}

add_filter( 'woocommerce_order_item_display_meta_value', 'change_order_item_meta_value', 20, 3 );

/**
 * Changing a meta value
 * @param  string        $value  The meta value
 * @param  WC_Meta_Data  $meta   The meta object
 * @param  WC_Order_Item $item   The order item object
 * @return string        The title
 */
/* Change in mail */
function change_order_item_meta_value( $value, $meta, $item ) {

    // By using $meta-key we are sure we have the correct one.
    if ( 'ovacrs_pickup_loc' === $meta->key ) { $key = esc_html__(' Pick-up Location ', 'ova-crs'); }
    if ( 'ovacrs_pickoff_loc' === $meta->key ) { $key = esc_html__(' Drop-off Location ', 'ova-crs'); }
    if ( 'ovacrs_pickup_date' === $meta->key ) { $key = esc_html__(' Pick-up date ', 'ova-crs'); }
    if ( 'ovacrs_pickoff_date' === $meta->key ) { $key = esc_html__(' Drop-off date ', 'ova-crs'); }
    if ( 'ovacrs_total_days' === $meta->key ) { $key = esc_html__(' Total Time ', 'ova-crs'); }
    if ( 'ovacrs_price_detail' === $meta->key ) { $key = esc_html__(' Price Detail ', 'ova-crs'); }
    if ( 'id_vehicle' === $meta->key ) { $key = esc_html__(' ID Vehicle ', 'ova-crs'); }
    if ( 'ovacrs_amount_insurance_product' === $meta->key ) { 
        $key =esc_html__( 'Amount Of Insurance', 'ova-crs' );
        $value = wc_price($meta->value);
    }
    if ( 'ovacrs_deposit_amount_product' === $meta->key ) { 
        $key =esc_html__( 'Deposit Amount', 'ova-crs' );
        $value = wc_price($meta->value);
    }
    if ( 'ovacrs_remaining_amount_product' === $meta->key ) { 
        $key =esc_html__( 'Remaining Amount', 'ova-crs' );
        $value = wc_price($meta->value);
    }
    
    if ( 'rental_type' === $meta->key ) { $key = esc_html__(' Rental Type ', 'ova-crs'); }
    if ( 'period_label' === $meta->key ) { $key = esc_html__(' Package ', 'ova-crs'); }
    if ( 'package_type' === $meta->key ) { $key = esc_html__(' Package Type ', 'ova-crs'); }
    
    if ( 'ovacrs_quantity' === $meta->key ) { $key = esc_html__(' Quantity ', 'ova-crs'); }


    return $value;
}

add_filter( 'wc_order_statuses', 'wc_closed_order_statuses' );
// Register in wc_order_statuses.
function wc_closed_order_statuses( $order_statuses ) {
    $order_statuses['wc-closed'] = _x( 'Closed', 'Order status', 'ova-crs' );

    return $order_statuses;
}

// Add Min, Max, radius
add_action( 'admin_footer', 'ovacrs_get_dateformat', 5 );
add_action( 'wp_head', 'ovacrs_get_dateformat', 5 );
function ovacrs_get_dateformat() { ?>
    <?php 
        $date_format = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
        $time_format = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

     ?>
    <script type="text/javascript">
        var date_format = '<?php echo esc_html__( $date_format ); ?>';
        var time_format = '<?php echo esc_html__( $time_format ); ?>';
    </script>

<?php }