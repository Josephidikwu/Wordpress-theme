<?php if ( !defined( 'ABSPATH' ) ) exit();

// hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'ovacrs_create_type_taxonomies', 0 );

// create two taxonomies, genres and writers for the post type "book"
function ovacrs_create_type_taxonomies() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Types', 'taxonomy general name', 'ova-crs' ),
		'singular_name'     => _x( 'type', 'taxonomy singular name', 'ova-crs' ),
		'search_items'      => __( 'Search Types', 'ova-crs' ),
		'all_items'         => __( 'All Type', 'ova-crs' ),
		'parent_item'       => __( 'Parent Type', 'ova-crs' ),
		'parent_item_colon' => __( 'Parent Type:', 'ova-crs' ),
		'edit_item'         => __( 'Edit Type', 'ova-crs' ),
		'update_item'       => __( 'Update Type', 'ova-crs' ),
		'add_new_item'      => __( 'Add New Type', 'ova-crs' ),
		'new_item_name'     => __( 'New Type Name', 'ova-crs' ),
		'menu_name'         => __( 'Type', 'ova-crs' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => apply_filters( 'show_admin_column_type', false),
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'type' ),
	);

	register_taxonomy( 'type', array( 'product' ), $args );

	

	// Add Manufacturer
	$labels_manufaceturer = array(
		'name'              => _x( 'Manufacturers', 'taxonomy general name', 'ova-crs' ),
		'singular_name'     => _x( 'Manufacture', 'taxonomy singular name', 'ova-crs' ),
		'search_items'      => __( 'Search Manufacturers', 'ova-crs' ),
		'all_items'         => __( 'All Manufacturer', 'ova-crs' ),
		'parent_item'       => __( 'Parent Manufacturer', 'ova-crs' ),
		'parent_item_colon' => __( 'Parent Manufacturer:', 'ova-crs' ),
		'edit_item'         => __( 'Edit Manufacturer', 'ova-crs' ),
		'update_item'       => __( 'Update Manufacturer', 'ova-crs' ),
		'add_new_item'      => __( 'Add New Manufacturer', 'ova-crs' ),
		'new_item_name'     => __( 'New Manufacturer Name', 'ova-crs' ),
		'menu_name'         => __( 'Manufacturer', 'ova-crs' ),
	);

	$args_manufacturer = array(
		'hierarchical'      => true,
		'labels'            => $labels_manufaceturer,
		'show_ui'           => true,
		'show_admin_column' => apply_filters( 'show_admin_column_manufacturer', false),
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'manufacturer' ),
	);

	register_taxonomy( 'manufacturer', array( 'product' ), $args_manufacturer );



	// Steering
	$labels_steering = array(
		'name'              => _x( 'Steerings', 'taxonomy general name', 'ova-crs' ),
		'singular_name'     => _x( 'Steering', 'taxonomy singular name', 'ova-crs' ),
		'search_items'      => __( 'Search Steerings', 'ova-crs' ),
		'all_items'         => __( 'All Steering', 'ova-crs' ),
		'parent_item'       => __( 'Parent Steering', 'ova-crs' ),
		'parent_item_colon' => __( 'Parent Steering:', 'ova-crs' ),
		'edit_item'         => __( 'Edit Steering', 'ova-crs' ),
		'update_item'       => __( 'Update Steering', 'ova-crs' ),
		'add_new_item'      => __( 'Add New Steering', 'ova-crs' ),
		'new_item_name'     => __( 'New Steering Name', 'ova-crs' ),
		'menu_name'         => __( 'Steering', 'ova-crs' ),
	);

	$args_steering = array(
		'hierarchical'      => true,
		'labels'            => $labels_steering,
		'show_ui'           => true,
		'show_admin_column' => apply_filters( 'show_admin_column_steering', false),
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'steering' ),
	);

	register_taxonomy( 'steering', array( 'product' ), $args_steering );

	// Gearbox
	$labels_gearbox = array(
		'name'              => _x( 'Gearboxs', 'taxonomy general name', 'ova-crs' ),
		'singular_name'     => _x( 'Gearbox', 'taxonomy singular name', 'ova-crs' ),
		'search_items'      => __( 'Search Gearboxs', 'ova-crs' ),
		'all_items'         => __( 'All Gearbox', 'ova-crs' ),
		'parent_item'       => __( 'Parent Gearbox', 'ova-crs' ),
		'parent_item_colon' => __( 'Parent Gearbox:', 'ova-crs' ),
		'edit_item'         => __( 'Edit Gearbox', 'ova-crs' ),
		'update_item'       => __( 'Update Gearbox', 'ova-crs' ),
		'add_new_item'      => __( 'Add New Gearbox', 'ova-crs' ),
		'new_item_name'     => __( 'New Gearbox Name', 'ova-crs' ),
		'menu_name'         => __( 'Gearbox', 'ova-crs' ),
	);

	$args_gearbox = array(
		'hierarchical'      => true,
		'labels'            => $labels_gearbox,
		'show_ui'           => true,
		'show_admin_column' => apply_filters( 'show_admin_column_gearbox', false),
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'gearbox' ),
	);

	register_taxonomy( 'gearbox', array( 'product' ), $args_gearbox );

	//Auto Park
	$labels_auto_park = array(
		'name'              => _x( 'Auto Park', 'taxonomy general name', 'ova-crs' ),
		'singular_name'     => _x( 'Auto Park', 'taxonomy singular name', 'ova-crs' ),
		'search_items'      => __( 'Search Auto Park', 'ova-crs' ),
		'all_items'         => __( 'All Auto Park', 'ova-crs' ),
		'parent_item'       => __( 'Parent Auto Park', 'ova-crs' ),
		'parent_item_colon' => __( 'Parent Auto Park:', 'ova-crs' ),
		'edit_item'         => __( 'Edit Auto Park', 'ova-crs' ),
		'update_item'       => __( 'Update Auto Park', 'ova-crs' ),
		'add_new_item'      => __( 'Add New Auto Park', 'ova-crs' ),
		'new_item_name'     => __( 'New Auto Park Name', 'ova-crs' ),
		'menu_name'         => __( 'Auto Park', 'ova-crs' ),
	);

	$args_auto_park = array(
		'hierarchical'      => true,
		'labels'            => $labels_auto_park,
		'show_ui'           => true,
		'show_admin_column' => apply_filters( 'show_admin_column_auto_park', false),
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'auto_park' ),
	);

	register_taxonomy( 'auto_park', array( 'product' ), $args_auto_park );
}
