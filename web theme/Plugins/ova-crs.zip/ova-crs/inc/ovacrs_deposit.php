<?php 
defined( 'ABSPATH' ) || exit();

//add row To pay, Remaining in Cart page
add_action( 'woocommerce_cart_totals_after_order_total',  'ovacrs_woocommerce_cart_totals_after_order_total',10,1 ); 
function ovacrs_woocommerce_cart_totals_after_order_total( $cart_object ){
    $has_deposit = isset(WC()->cart->deposit_info[ '_ova_has_deposit' ]) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';

    if ( isset(WC()->cart->deposit_info[ 'ova_deposit_amount' ]) && $has_deposit ){
        $total = WC()->cart->total;

        if ( WC()->cart->deposit_info[ 'ova_type_deposit' ] === 'full' ) {
            $deposit_amount = $total;
        } else {
            $deposit_amount = WC()->cart->deposit_info[ 'ova_deposit_amount' ];
        }
    
    ?>
    <tr class="order-paid">
        <th><?php esc_html_e('To Pay','ova-crs') ?></th>
        <td data-title="<?php echo $to_pay_text; ?>">
            <strong><?php echo wc_price ( $deposit_amount ) ?></strong></td>
    </tr>
    <tr class="order-remaining">
        <th><?php esc_html_e('Remaining','ova-crs') ?></th>
        <td data-title="<?php echo $second_payment_text; ?>">
            <strong><?php echo wc_price( $total - $deposit_amount ) ?></strong></td>
    </tr>
    <?php
    }
}

//add row To pay, Remaining in checkout page
add_action('woocommerce_review_order_after_order_total', 'ovacrs_woocommerce_review_order_after_order_total');
function ovacrs_woocommerce_review_order_after_order_total ($order) {
    $has_deposit = isset(WC()->cart->deposit_info[ '_ova_has_deposit' ]) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';

    if ( isset(WC()->cart->deposit_info[ 'ova_deposit_amount' ]) && $has_deposit ){
        $total = WC()->cart->total;

        if ( WC()->cart->deposit_info[ 'ova_type_deposit' ] === 'full' ) {
            $deposit_amount = $total;
        } else {
            $deposit_amount = WC()->cart->deposit_info[ 'ova_deposit_amount' ];
        }
        ?>
        <tr class="order-paid">
            <th><?php esc_html_e('To Pay','ova-crs') ?></th>
            <td data-title="<?php echo $to_pay_text; ?>">
                <strong><?php echo wc_price ( $deposit_amount ) ?></strong></td>
        </tr>
        <tr class="order-remaining">
            <th><?php esc_html_e('Remaining','ova-crs') ?></th>
            <td data-title="<?php echo $second_payment_text; ?>">
                <strong><?php echo wc_price( $total - $deposit_amount ) ?></strong></td>
        </tr>
        <?php
        }
}


//add row To pay, Remaining in success checkout 
add_filter( 'woocommerce_get_order_item_totals' , 'get_order_item_totals' , 10 , 2 );
function get_order_item_totals( $total_rows , $order ){
    $order_has_deposit = $order->get_meta( '_ova_has_deposit' , true );
    $deposit_amount = !empty($order->get_meta( '_ova_deposit_amount' , true )) ? floatval($order->get_meta( '_ova_deposit_amount' , true )) : 0;
    $remaining_amount = $order->get_meta( '_ova_remaining_amount' , true );
    if( $order_has_deposit )  :

        if( is_checkout() ){

            $total_rows[ 'deposit_amount' ] = array(
                'label' => esc_html('To Pay:', 'ova-crs'),
                'value' => wc_price( $deposit_amount , array( 'currency' => $order->get_currency() ) )
            );

            $total_rows[ 'remaining_amount' ] = array(
                'label' => esc_html('Remaining:', 'ova-crs'),
                'value' => wc_price( $remaining_amount , array( 'currency' => $order->get_currency() ) )
            );
        }

    endif;
    return $total_rows;
}

//set price is deposit amount and set_meta data (deposit amount, remaining);
add_action('woocommerce_checkout_order_processed', 'ova_checkout_order_processed', 10, 2);
function ova_checkout_order_processed($order_id) {

    $order = wc_get_order($order_id);
    $has_deposit = isset(WC()->cart->deposit_info[ '_ova_has_deposit' ]) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';
    $insurance_amount = WC()->cart->deposit_info['ova_insurance_amount'];
    $original_total = WC()->cart->total;

    if ( WC()->cart->deposit_info[ 'ova_type_deposit' ] === 'full' ) {
        $deposit_amount = $original_total;
    } else {
        $deposit_amount = WC()->cart->deposit_info[ 'ova_deposit_amount' ];
    }

    $remaining_amount = $original_total - $deposit_amount;

    $order->add_meta_data('_ova_insurance_amount', $insurance_amount, true);
    if ( $has_deposit ) {

        $order->set_total($deposit_amount);
        $order->add_meta_data('_ova_deposit_amount', $deposit_amount, true);
        $order->add_meta_data('_ova_remaining_amount', $remaining_amount, true);
        
        $order->add_meta_data('_ova_original_total', $original_total, true);
        $order->add_meta_data('_ova_has_deposit', $has_deposit, true);
        $order->save();
    } else {
        $order->delete_meta_data('_ova_deposit_amount');
        $order->delete_meta_data('_ova_remaining_amount');
        $order->delete_meta_data('_ova_original_total');
        $order->delete_meta_data('_ova_has_deposit');
        $order->save();
    }
}

//set total original if has deposit display total is checkout page, else set_total to display is order admin page
add_filter( 'woocommerce_order_get_total' ,'ova_get_order_total', 10 , 2 );
function ova_get_order_total( $total , $order ){

    $has_deposit = $order->get_meta( '_ova_has_deposit' , true );
    $_ova_original_total = $order->get_meta( '_ova_original_total' , true );
    if ( $has_deposit && !did_action('valid-paypal-standard-ipn-request') && (is_order_received_page()  || ! is_checkout()) )  {
        $total = $_ova_original_total;
        $order->set_total($total);
    } 

    return $total;
}


//add column is amount deposit in order admin page
add_filter( 'manage_edit-shop_order_columns', 'add_deposit_column', 10, 1 );
add_action( 'manage_shop_order_posts_custom_column','ova_populate_deposit_column', 10, 1 );

function add_deposit_column($columns){

    $new_columns = array();

    foreach($columns as $key => $column){

        if($key === 'order_total'){
            $new_columns['ova_amount_deposit_column'] = esc_html('Deposit', 'ova-crs');
        }
        $new_columns[$key] = $column;

    }

    return $new_columns;

}
function ova_populate_deposit_column($column){

    if ( 'ova_amount_deposit_column' === $column ) {
        global $post;
        $order = wc_get_order($post->ID);
        if($order){
            $order_amount_deposit = $order->get_meta( '_ova_deposit_amount' , true );
            if ($order_amount_deposit) {
            ?>
                <span class="ova_deposit_amount"><?php echo wc_price($order_amount_deposit) ?></span>
            <?php
            }
        }
    }

}


//add column is amount remaining
add_filter( 'manage_edit-shop_order_columns', 'add_amount_remaining_column', 10, 2 );
add_action( 'manage_shop_order_posts_custom_column','ova_populate_amount_remaining_column', 10, 2 );

function add_amount_remaining_column($columns){

    $new_columns = array();

    foreach($columns as $key => $column){

        if($key === 'order_total'){
            $new_columns['ova_amount_remaing_column'] = esc_html('Remaining', 'ova-crs');
        }
        $new_columns[$key] = $column;

    }

    return $new_columns;

}
function ova_populate_amount_remaining_column($column){

    if ( 'ova_amount_remaing_column' === $column ) {
        global $post;
        $order = wc_get_order($post->ID);
        $order_amount_deposit = $order->get_meta( '_ova_remaining_amount' , true );
        ?>
        <span class="ova_amount_remaining_column "><?php echo wc_price($order_amount_deposit) ?></span>
        <?php
    }

}

//add column status deposit
add_filter( 'manage_edit-shop_order_columns', 'ova_add_status_deposit_column', 10, 2 );
add_action( 'manage_shop_order_posts_custom_column','ova_populate_status_deposit_column', 10, 2 );

function ova_add_status_deposit_column($columns){

    $new_columns = array();

    foreach($columns as $key => $column){

        if($key === 'order_total'){
            $new_columns['ova_status_deposit_column'] = esc_html('Status deposit', 'ova-crs');
        }
        $new_columns[$key] = $column;

    }

    return $new_columns;

}
function ova_populate_status_deposit_column($column){

    if ( 'ova_status_deposit_column' === $column ) {
        global $post;
        $order = wc_get_order($post->ID);
        $order_amount_remaining = $order->get_meta( '_ova_remaining_amount' , true );

        if ($order_amount_remaining == 0) {
            ?>
                <span class="ova_amount_status_deposit_column ova_paid"><?php esc_html_e('Paid', 'ova-crs') ?></span>
            <?php
        } else {
            ?>
                <span class="ova_amount_status_deposit_column ova_pending"><?php esc_html_e('Pending Payment', 'ova-crs') ?></span>
            <?php
        }
        ?>

        
        <?php
    }

}


//add column status process insurance 
add_filter( 'manage_edit-shop_order_columns', 'ova_add_status_insurance_column', 10, 2 );
add_action( 'manage_shop_order_posts_custom_column','ova_populate_status_insurance_column', 10, 2 );

function ova_add_status_insurance_column($columns){

    $new_columns = array();

    foreach($columns as $key => $column){

        if($key === 'order_total'){
            $new_columns['ova_status_insurance_column'] = esc_html('Status Insurance', 'ova-crs');
        }
        $new_columns[$key] = $column;

    }

    return $new_columns;

}
function ova_populate_status_insurance_column($column){

    if ( 'ova_status_insurance_column' === $column ) {
        global $post;
        $order = wc_get_order($post->ID);
        $order_amount_insurance = $order->get_meta( '_ova_insurance_amount' , true );

        if ($order_amount_insurance == 0) {
            ?>
                <span class="ova_amount_status_insurance_column ova_paid"><?php esc_html_e('Paid', 'ova-crs') ?></span>
            <?php
        } else {
            ?>
                <span class="ova_amount_status_deposit_column ova_pending"><?php esc_html_e('Pending Payment', 'ova-crs') ?></span>
            <?php
        }
        ?>

        
        <?php
    }

}


//add column and display Deposit amount and Remaining amount in detail order
add_action( 'woocommerce_admin_order_item_headers' , 'ova_admin_order_item_headers' );
add_action( 'woocommerce_admin_order_item_values' , 'ova_admin_order_item_values', 10, 3 );

function ova_admin_order_item_headers(){
    ?>
    <th class="insurance-amount"><?php _e( 'Amount Insurance' , 'ova-crs' ); ?></th>
    <th class="deposit-paid"><?php _e( 'Deposit' , 'ova-crs' ); ?></th>
    <th class="deposit-remaining"><?php _e( 'Remaining' , 'ova-crs' ); ?></th>
    <?php
}

function ova_admin_order_item_values( $product , $item , $item_id ){
    global $post;
    $deposit_meta = null;

    if( !$product ) return;

    if( $product ){
        $deposit_meta = isset( $item[ 'wc_deposit_meta' ] ) ? $item[ 'wc_deposit_meta' ] : null;
    }
    $total = $item->get_total();
    $ovacrs_deposit_amount = isset( $item[ 'ovacrs_deposit_amount_product' ] ) ? floatval($item[ 'ovacrs_deposit_amount_product' ]) : 0;
    $ovacrs_remaining_amount = isset( $item[ 'ovacrs_remaining_amount_product' ] ) ? floatval($item[ 'ovacrs_remaining_amount_product' ]) : 0;
    $ovacrs_amount_insurance = isset( $item[ 'ovacrs_amount_insurance_product' ] ) ? floatval($item[ 'ovacrs_amount_insurance_product' ]) : 0;
    
    ?>
    <td class="ova-amount-insurance" width="1%">
        <div class="view">
            <?php
            if( isset($ovacrs_amount_insurance) ) 
                echo wc_price( $ovacrs_amount_insurance );
            ?>
        </div>
        <?php if( $product && $ovacrs_remaining_amount <= 0 ){ 
            ?>
            <div class="edit" style="display: none;">
               <input type="text" name="amount_insurance[<?php echo absint( $item_id ); ?>]"
               placeholder="<?php echo wc_format_localized_price( 0 ); ?>" value="<?php echo $ovacrs_amount_insurance; ?>"
               class="amount_insurance wc_input_price" data-total="<?php echo $ovacrs_amount_insurance; ?>"/>
            </div>
        <?php } ?>
    </td>

    <td class="ova-deposit-paid" width="1%">
        <div class="view">
            <?php
            if( isset($ovacrs_deposit_amount) && !empty($ovacrs_deposit_amount) )
                echo wc_price( $ovacrs_deposit_amount );
            ?>
        </div>

        <?php if( $product ){ ?>
            <div class="edit" style="display: none;">
                <input type="text" name="amount_deposit[<?php echo absint( $item_id ); ?>]"
                       placeholder="<?php echo wc_format_localized_price( 0 ); ?>" value="<?php echo $ovacrs_deposit_amount; ?>"
                       class="amount_deposit wc_input_price" data-total="<?php echo $ovacrs_deposit_amount; ?>"/>
            </div>
        <?php } ?>
        
    </td>
    <td class="deposit-remaining" width="1%">
        <div class="view">
            <?php
            if( isset($ovacrs_remaining_amount) )
                echo wc_price( $ovacrs_remaining_amount );
            ?>
        </div>

        <?php if( $product ){ ?>
            <div class="edit" style="display: none;">
                <input type="text" disabled="disabled" name="amount_remaining[<?php echo absint( $item_id ); ?>]"
                       placeholder="<?php echo wc_format_localized_price( 0 ); ?>" value="<?php echo $ovacrs_remaining_amount; ?>"
                       class="amount_remaining wc_input_price" data-total="<?php echo $ovacrs_remaining_amount; ?>"/>
            </div>
        <?php } ?>
    </td>
    <?php
}

//dissplay total deposit and total ramaining in order detail
add_action( 'woocommerce_admin_order_totals_after_total' , 'ova_admin_order_totals_after_total', 10, 3 );
function ova_admin_order_totals_after_total( $order_id ){
    $order = wc_get_order( $order_id );
    $deposit_amount = !empty($order->get_meta( '_ova_deposit_amount' , true )) ? floatval($order->get_meta( '_ova_deposit_amount' , true )) : 0;
    $remaining_amount = !empty($order->get_meta( '_ova_remaining_amount' , true )) ? floatval($order->get_meta( '_ova_remaining_amount' , true )) : 0;
    $insurance_amount = !empty($order->get_meta( '_ova_insurance_amount' , true )) ? floatval($order->get_meta( '_ova_insurance_amount' , true )) : 0;

    ?>

    <?php if ( ! empty($deposit_amount) ) : ?>
    <tr>
        <td class="label"><?php _e( 'Total Deposit Amount' , 'ova-crs' ); ?>
        </td>
        <td>
        </td>
        <td class="paid">
            <div class="view"><?php echo wc_price( $deposit_amount , array( 'currency' => $order->get_currency() ) ); ?></div>
        </td>
    </tr>
    <?php endif ?>
    <tr>
        <td class="label"><?php _e( 'Total Remaining Amount' , 'ova-crs' ); ?>:</td>
        <td>
        </td>
        <td class="remaining">
            <div class="view"><?php echo wc_price( $remaining_amount , array( 'currency' => $order->get_currency() ) ); ?></div>
        </td>
    </tr>

    <tr>
        <td class="label"><?php _e( ' Total Insurance Amount' , 'ova-crs' ); ?>:</td>
        <td>
        </td>
        <td class="remaining">
            <div class="view"><?php echo wc_price( $insurance_amount , array( 'currency' => $order->get_currency() ) ); ?></div>
        </td>
    </tr>

    <?php
}


add_action( 'woocommerce_saved_order_items' , 'ova_saved_order_items' , 10 , 2 );

function ova_saved_order_items( $order_id , $items ){

    $order = wc_get_order( $order_id );
    $order->read_meta_data( true );
    $has_deposit = !empty($order->get_meta( '_ova_has_deposit' , true )) ? floatval($order->get_meta( '_ova_has_deposit' , true )) : 0;

    if( isset( $items[ 'order_item_id' ] ) && $_POST[ 'action' ] === 'woocommerce_save_order_items' ){

        $amount_insurance = isset( $items[ 'amount_insurance' ] ) ? $items[ 'amount_insurance' ] : array();
        $amount_deposit = isset( $items[ 'amount_deposit' ] ) ? $items[ 'amount_deposit' ] : array();
        $total_order = $total_deposit_amount =  $total_remaining_amount = $total_insurance_amount = 0;
        foreach( $items[ 'order_item_id' ] as $item_id ){

            // $amount_insurance = isset( $amount_insurance[ $item_id ] ) ? floatval( wc_format_decimal( $amount_insurance[ $item_id ] ) ) : wc_get_order_item_meta( $item_id, 'ovacrs_amount_insurance_product', true );
            $paid = isset( $amount_deposit[ $item_id ] ) ? floatval( wc_format_decimal( $amount_deposit[ $item_id ] ) ) : null;
            $total = floatval(wc_get_order_item_meta( $item_id , '_line_total' ));

            $original_deposit = wc_get_order_item_meta( $item_id, 'ovacrs_deposit_amount_product', true );

            // wc_update_order_item_meta( $item_id , 'ovacrs_amount_insurance' , $amount_insurance );
            if ($paid !== null) {
                wc_update_order_item_meta( $item_id , 'ovacrs_deposit_amount_product' , $paid );
                wc_update_order_item_meta( $item_id , 'ovacrs_remaining_amount_product' , $total - $paid );
            }

            
            // && $paid ==  $original_deposit
            if ( isset( $amount_insurance[ $item_id ] )  ) {

                $original_insurance_amount = floatval(wc_get_order_item_meta( $item_id, 'ovacrs_amount_insurance_product', true ));
               
                //update amount insurance
                wc_update_order_item_meta( $item_id , 'ovacrs_amount_insurance_product' , floatval($amount_insurance[ $item_id ]) );

                $amount_insurance_update_total = floatval($amount_insurance[ $item_id ]) - $original_insurance_amount;
                // //update deposit, total
                wc_update_order_item_meta( $item_id , 'ovacrs_deposit_amount_product' , $paid + $amount_insurance_update_total );
                wc_update_order_item_meta( $item_id , '_line_total' , $total + $amount_insurance_update_total );
                wc_update_order_item_meta( $item_id , '_line_subtotal' , $paid + $amount_insurance_update_total );

            }
            // wc_update_order_item_meta( $item_id , 'ovacrs_amount_insurance_product' , $amount_insurance );
            $sub_total = wc_get_order_item_meta( $item_id , '_line_total' );

            $sub_insurance_amount = wc_get_order_item_meta( $item_id, 'ovacrs_amount_insurance_product', true );
            $sub_deposit_amount = wc_get_order_item_meta( $item_id, 'ovacrs_deposit_amount_product', true );
            $sub_remaining_amount = wc_get_order_item_meta( $item_id, 'ovacrs_remaining_amount_product', true );

            $total_insurance_amount += $sub_insurance_amount;
            $total_deposit_amount += $sub_deposit_amount;
            $total_remaining_amount += $sub_remaining_amount;
            $total_order += $sub_total;
        }

        $order->update_meta_data( '_ova_insurance_amount' , $total_insurance_amount );
        $order->update_meta_data( '_ova_deposit_amount' , $total_deposit_amount );
        $order->update_meta_data( '_ova_remaining_amount' , $total_remaining_amount );
        $order->set_total($total_order);
        $order->save();
    }

}


