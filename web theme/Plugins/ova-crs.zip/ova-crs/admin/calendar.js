(function($){
	"use strict";
	$(document).ready(function(){

		var day_of_week_start = 1;
        if (typeof(dayOfWeekStart) != "undefined"){
            day_of_week_start = dayOfWeekStart;
        }

		if( typeof order_time != 'undefined' ){
		
			$('.ireca__product_calendar').each(function(){
				var nav = $(this).data('nav');
				var default_view = $(this).data('default_view');
				var more_text = $(this).data( 'more_text' );
				var cal_lang = $(this).data( 'lang' ).replace(/\s/g, '');

				/* Show/hide read more */
				var eventLimit = true;
				var view_eventLimit = 1;

				var show_read_more_date = $(this).data('show_read_more_date');

				if( show_read_more_date == 'hide_read_more_date' ){
					eventLimit = false;
					view_eventLimit = 0;
				}

				$(this).fullCalendar({
			      header: {
			        left: 'prev,next today ',
			        center: 'title',
			        right: nav
			      },
			      
			      defaultView: default_view,
			      eventLimit: eventLimit,
			      events: order_time,
			      eventLimitText: more_text,
			      firstDay: day_of_week_start,
			      showNonCurrentDates: true,
			      locale: cal_lang,
			      views: {
				    month: {
				      eventLimit: view_eventLimit /* adjust to 6 only for agendaWeek/agendaDay */
				    },
				    agenda: {
				      eventLimit: view_eventLimit /* adjust to 6 only for agendaWeek/agendaDay */
				    },
				    week:{
				    	eventLimit: view_eventLimit	
				    }
				  }
			    });
			});

		}
	});

}) (jQuery);