var dateformat = 'yy-m-d';
if (typeof(date_format) != "undefined"){
    dateformat = date_format;
}

var timeformat = 'H:i';
if (typeof(time_format) != "undefined"){
    timeformat = time_format;
}


jQuery(document).on('change',  '.update_order_status', function(e){
	
	var order_status_text = jQuery(this).children("option:selected").html();
	var new_order_status_val = jQuery(this).children("option:selected").val();

	var prompt_ask = confirm("Do you want to "+order_status_text+' Booking ?');

	if (prompt_ask == true && new_order_status_val != '') {

		var order_id = jQuery(this).data('order_id');
		
		var new_order_status_class = jQuery(this).children("option:selected").val().replace( 'wc-', '' );
		

		

		var order_status_place = jQuery(this).closest('.order_status').find('.order-status');
		var order_status_place_text = jQuery(this).closest('.order_status').find('.order-status span');
		
			var data = {
				'action': 'update_order_status_woo',
				'order_id': order_id,
				'new_order_status': new_order_status_val
			}

			jQuery.post( ajaxurl, data, function( response ) {
				// append_place.append(response);
				order_status_place.attr('class', '');
				order_status_place.addClass('order-status tips status-'+new_order_status_class);
				order_status_place_text.html(new_order_status_class);
				
				
			});
	}
	e.preventDefault();
});

var day_of_week_start = 1;
if (typeof(dayOfWeekStart) != "undefined"){
    day_of_week_start = dayOfWeekStart;
}

jQuery('.date_book').each(function(){
    var today = new Date();
    var datePickerOptions = {
        format: dateformat,
        changeMonth: true,
        dayOfWeekStart: day_of_week_start,
        step: 30,
        changeYear: true
    }
    jQuery(this).datetimepicker(datePickerOptions);
});

/* Price Type Change */
jQuery("#general_product_data").each(function(){

	jQuery(this).bind( "change_price_type", function(){

		var ovacrs_price_type = jQuery(this).find('select#ovacrs_price_type :selected').val();
	
		if( ovacrs_price_type == 'period_time' ){

			jQuery(this).find( '.price_period_time' ).show();
			
			

			jQuery(this).find('.price_not_period_time').hide();
			jQuery(this).find('.ovacrs_regul_price_hour_field').hide();
            jQuery(this).find('.ovacrs_local_price_wrap').hide();
            jQuery(this).find('.ovacrs_unfixed_time_field').show();

		}else if( ovacrs_price_type == 'transportation' ){

            // jQuery(this).find('._regular_price_field').hide();
            jQuery(this).find('.price_period_time').hide();
            jQuery(this).find('.ovacrs_regul_price_hour_field').hide();

            jQuery(this).find( '.price_not_period_time ' ).hide();
            jQuery(this).find( '.price_period_time' ).hide();

            jQuery(this).find('.ovacrs_local_price_wrap').show();

            jQuery(this).find('.ovacrs_unfixed_time_field').hide();

            jQuery(this).find('.ovacrs_local_price ').removeClass('ovacrs-day');

        } else {
			jQuery(this).find( '.price_period_time' ).hide();

			jQuery(this).find('.price_not_period_time').show();
			jQuery(this).find('.ovacrs_regul_price_hour_field').show();

            jQuery(this).find('.ovacrs_local_price_wrap').hide();
            jQuery(this).find('.ovacrs_unfixed_time_field').hide();

            if( ovacrs_price_type == 'day' ){
                jQuery(this).find('.ovacrs_local_price_wrap').show();
                jQuery(this).find('.ovacrs_local_price ').addClass('ovacrs-day');
            }
		}
				
	});

	jQuery(this).trigger("change_price_type");
	jQuery(this).find('select#ovacrs_price_type').change(function(){
		jQuery(this).trigger("change_price_type");
	});

});
var val_enable = jQuery('.woocommerce_options_panel #ovacrs_enable_deposit').val();
if (val_enable === 'no') {
	jQuery('.woocommerce_options_panel .ovacrs_force_deposit_field').css('display', 'none');
	jQuery('.woocommerce_options_panel .ovacrs_type_deposit_field').css('display', 'none');
	jQuery('.woocommerce_options_panel .ovacrs_amount_deposit_field').css('display', 'none');
} else {
	jQuery('.woocommerce_options_panel .ovacrs_force_deposit_field').css('display', 'block');
	jQuery('.woocommerce_options_panel .ovacrs_type_deposit_field').css('display', 'block');
	jQuery('.woocommerce_options_panel .ovacrs_amount_deposit_field').css('display', 'block');
}
jQuery('.woocommerce_options_panel #ovacrs_enable_deposit').on('change', function(){
	var val_enable = jQuery(this).val();
	if (val_enable === 'no') {
		jQuery('.woocommerce_options_panel .ovacrs_force_deposit_field').css('display', 'none');
		jQuery('.woocommerce_options_panel .ovacrs_type_deposit_field').css('display', 'none');
		jQuery('.woocommerce_options_panel .ovacrs_amount_deposit_field').css('display', 'none');
	} else {
		jQuery('.woocommerce_options_panel .ovacrs_force_deposit_field').css('display', 'block');
		jQuery('.woocommerce_options_panel .ovacrs_type_deposit_field').css('display', 'block');
		jQuery('.woocommerce_options_panel .ovacrs_amount_deposit_field').css('display', 'block');
	}
});

//change deposit_paid
jQuery('body')
    .on('change', '.woocommerce_order_items input.amount_deposit', function() {
      var row = jQuery(this).closest('tr.item');
      var paid = jQuery(this).val();
      var remaining = jQuery('input.deposit_remaining', row);
      var total = jQuery('input.line_total', row);
      if (paid !== '' && parseFloat(total.val()) - parseFloat(paid) > 0)
        remaining.val(parseFloat(total.val()) - parseFloat(paid));
      else
        remaining.val('');
    })

    .on('change', '.woocommerce_order_items input.line_total', function() {
      var row = jQuery(this).closest('tr.item');
      var remaining = jQuery('input.amount_remaining', row);
      var paid = jQuery('input.deposit_paid', row);
      var total = jQuery(this).val();
      if (paid.val() !== '' && parseFloat(total) - parseFloat(paid.val()) >= 0)
        remaining.val(parseFloat(total) - parseFloat(paid.val()));
      else
        remaining.val('');
    });


//js checkout field
var OVA_OPTION_ROW_HTML  = '';
    OVA_OPTION_ROW_HTML += '<tr>';
    OVA_OPTION_ROW_HTML += '<td ><input type="text" name="ova_options_key[]" placeholder="Option Value" /></td>';
    OVA_OPTION_ROW_HTML += '<td ><input type="text" name="ova_options_text[]" placeholder="Option Text" /></td>';
    OVA_OPTION_ROW_HTML += '<td class="ova-box"><a href="javascript:void(0)" onclick="ovaAddNewOptionRow(this)" class="btn btn-blue" title="Add new option">+</a></td>';
    OVA_OPTION_ROW_HTML += '<td class="ova-box"><a href="javascript:void(0)" onclick="ovadRemoveOptionRow(this)" class="btn btn-red" title="Remove option">x</a></td>';
    OVA_OPTION_ROW_HTML += '<td class="ova-box sort ui-sortable-handle"></td>';
    OVA_OPTION_ROW_HTML += '</tr>';

function ovaAddNewOptionRow(e){

    var table = jQuery(e).closest('table');
    var optionsSize = table.find('tbody tr').size();


    var height = jQuery('.ova-wrap-popup-ckf').attr('height');
    if(height) {
        height = parseInt(height) + 5;
    } else {
        height = 110;
    }
    
    jQuery('.ova-wrap-popup-ckf').attr('height', height);
    jQuery('.ova-wrap-popup-ckf').css('height', height + 'vh');
    if(optionsSize > 0){
        table.find('tbody tr:last').after(OVA_OPTION_ROW_HTML);
    }else{
        
        table.find('tbody').append(OVA_OPTION_ROW_HTML);        
    }
}

jQuery('input[name="remove"]').on('click', function(e) {
    var result = ovacrsconfirmRemove('Are you sure?');
    if(!result) {
        e.preventDefault();
    }
    
})

function ovadRemoveOptionRow(e){

    var table = jQuery(e).closest('table');
    jQuery(e).closest('tr').remove();
    var optionsSize = table.find('tbody tr').size();
        
    if(optionsSize == 0){
        table.find('tbody').append(OVA_OPTION_ROW_HTML);
    }
}

function ovacrsconfirmRemove( $mess="" ) {
    var result = confirm($mess);
    return result;
}


function ovacrsEditFieldForm(data) {
    data = JSON.parse(data);

    var name = data.name;
    var type = (data.type) ? data.type : 'text';
    var label = data.label;
    var placeholder = data.placeholder;
    var default_value = data.default;
    var ova_class = data.class;
    var ova_required = data.required;
    var ova_enabled = data.enabled;

    var ova_options_key = data.ova_options_key;
    var ova_options_text = data.ova_options_text;

    if( ova_required == 'on' ) {
        jQuery('#ova_required').prop('checked', true);
    } else {
        jQuery('#ova_required').prop('checked', false);
    }

    if( ova_enabled == 'on' ) {
        jQuery('#ova_enable').prop('checked', true);
    } else {
        jQuery('#ova_enable').prop('checked', false);
    }

    if( type == 'select' ) {
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.ova-row-placeholder').css('display', 'none');
    } else {
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.ova-row-placeholder').css('display', 'table-row');
    }

    var option_html_edit = '';
    jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options table.ova-sub-table tbody').empty();
    if( type === 'select' ) {

        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options').css('display', 'table-row');
        ova_options_key.forEach(function(item, key){
            option_html_edit += '<tr>';
            option_html_edit += '<td ><input type="text" name="ova_options_key[]" placeholder="Option Value" value="'+item+'" /></td>';
            option_html_edit += '<td ><input type="text" name="ova_options_text[]" placeholder="Option Text" value="'+ova_options_text[key]+'" /></td>';
            option_html_edit += '<td class="ova-box"><a href="javascript:void(0)" onclick="ovaAddNewOptionRow(this)" class="btn btn-blue" title="Add new option">+</a></td>';
            option_html_edit += '<td class="ova-box"><a href="javascript:void(0)" onclick="ovadRemoveOptionRow(this)" class="btn btn-red" title="Remove option">x</a></td>';
            option_html_edit += '<td class="ova-box sort ui-sortable-handle"></td>';
            option_html_edit += '</tr>';
        });
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options table.ova-sub-table tbody').append(option_html_edit)
    } else {
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options').css('display', 'none');
    }


    jQuery('#ova_popup_field_form input[name="ova_action"]').val('edit');
    jQuery('#ova_popup_field_form input[name="ova_old_name"]').val(name);

    jQuery('#ova_type').val(type);
    jQuery('#ova_popup_field_form .ova-row-name input').val(name);
    jQuery('#ova_popup_field_form .ova-row-label input').val(label);
    jQuery('#ova_popup_field_form .ova-row-placeholder input').val(placeholder);
    jQuery('#ova_popup_field_form .ova-row-default input').val(default_value);
    jQuery('#ova_popup_field_form .ova-row-class input').val(ova_class);

    jQuery('.ova-wrap-popup-ckf').css('display', 'block');
}


function ovacrsOpenNewFieldForm() {
    jQuery('#ova_popup_field_form input[name="ova_action"]').val('new');
    jQuery('#ova_popup_field_form input[name="ova_old_name"]').val('');
    jQuery('.ova-wrap-popup-ckf').css('display', 'block');

    
}



function ovacrsSelectedAllField(elm) {
    var checkAll = jQuery(elm).prop('checked');
    jQuery( '.ova-list-checkout-field table tbody tr td.ova-checkbox input' ).prop( 'checked', checkAll );
}

function ovaClosePopup() {
    jQuery('.ova-wrap-popup-ckf').css('display', 'none');
}

var ovacrs_manage_custom_checkout_field = jQuery( '#ovacrs_manage_custom_checkout_field' ).val();
if( ovacrs_manage_custom_checkout_field !== 'new' ) {
    jQuery( '.ovacrs_product_custom_checkout_field_field' ).css('display', 'none');
}
jQuery('#ovacrs_manage_custom_checkout_field').on('change', function(){
    jQuery('.ovacrs_product_custom_checkout_field_field').css('display', 'block');
    if( jQuery(this).val() == 'all' ) {
        jQuery('.ovacrs_product_custom_checkout_field_field').css('display', 'none');
    }
});

jQuery('#ova_type').on('change', function(){
    jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options').css('display', 'none');
    jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.ova-row-placeholder').css('display', 'table-row');
    if( jQuery(this).val() == 'select' ) {
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.row-options').css('display', 'table-row');
        jQuery('.ova-wrap-popup-ckf .ova-popup-wrapper tr.ova-row-placeholder').css('display', 'none');
    }
});



// create order 
choosetime();
jQuery( document ).ready(function(){

    //view total cost
    jQuery('.ovacrs-order .view_total_cost').on('click',function() {
        var thisItem = jQuery(this).closest('.item');

        var id_product = jQuery(thisItem).find('.ovacrs_name_product').val();
        var start_date = jQuery(thisItem).find('.ovacrs_start_date').val();
        var end_date = jQuery(thisItem).find('.ovacrs_end_date').val();

        var symbol = jQuery(this).data('symbol');
        var rental_type = jQuery(thisItem).find('#ovacrs-rental-type').val();

        var id_package = '';
        if( rental_type == 'period_time' ) {
             var id_package = jQuery(thisItem).find('#ovacrs-package').val();
        }

        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'none');

        jQuery.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: ({
                action: 'ovacrs_get_total_price_and_quantity',
                id_product: id_product,
                start_date: start_date,
                end_date: end_date,
                id_package: id_package,
            }),
            success: function(response){

                var data = jQuery.parseJSON(response);
                var error = data.error;

                if( ! error ) {
                    var quantity = data.quantity;
                    var line_total = data.line_total;
                    var product_price = data.product_price;

                    jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'block');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'block');

                    
                    jQuery(thisItem).find('#ovacrs-price-detail').val(product_price);
                    jQuery(thisItem).find('#ovacrs-ovacrs-total-time').val(quantity);

                    
                    jQuery(thisItem).find('#ovacrs-total-product').val(line_total);

                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'inline-block');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-error').children('.ovacrs-error-span').text(data.message);
                }                
                
            },
        })

    });

    
    jQuery('.ovacrs-order .ovacrs_name_product').on('change',function() {

        var name_product = jQuery(this).val();
        var thisItem = jQuery(this).parent('.rental_item').parent('.sub-item').parent('.item');
        var symbol = jQuery(this).data('symbol');

        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'none');

        if( name_product ) {
            jQuery(thisItem).children('.sub-item.ovabrw-meta').css('display', 'block');
        } else {
            jQuery(thisItem).children('.sub-item.ovabrw-meta').css('display', 'none');
        }
        
        jQuery.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: ({
                action: 'ovacrs_load_data_product_create_order',
                name_product: name_product,
            }),
            success: function(response){
                var data = jQuery.parseJSON(response);
  
                var rental_type = data.rental_type;
                var petime_id_arr = data.petime_id;
                var id_vehicles_arr = data.ovacrs_id_vehicles;
                var ovacrs_amount_insurance = data.ovacrs_amount_insurance;
                var product_price = data.product_price;

                jQuery(thisItem).find('#ovacrs-price-detail').val(product_price + ' ' + symbol);

                jQuery(thisItem).children('.sub-item').children('.rental_type').children("select").children("option[value='"+rental_type+"']").attr('selected', 'selected');

                var flag_package = false;
                var html_id_vehicle = '';
                var html_pentime = '';
                html_pentime += '<select id="ovacrs-package" class="select_ovacrs_package" name="ovacrs_package[]">';
                if ( rental_type === 'period_time' && petime_id_arr ) {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-dropoff').css('display', 'none');
                    flag_package = true;
                    for (let key in petime_id_arr){
                        if ( petime_id_arr.hasOwnProperty( key ) ) {
                            html_pentime += '<option value="' + petime_id_arr[key] + '">' + petime_id_arr[key] + '</option>';
                        }
                    }
                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-dropoff').css('display', 'block');
                }
                html_pentime += '</select>';

                html_id_vehicle += '<select id="ovacrs-id-vehicle" class="select_ovacrs_id_vehicle" name="ovacrs_id_vehicle[]">';
                if ( id_vehicles_arr  ) {
                    for (let key_id in id_vehicles_arr){
                        if ( id_vehicles_arr.hasOwnProperty( key_id ) ) {
                            html_id_vehicle += '<option value="' + id_vehicles_arr[key_id] + '">' + id_vehicles_arr[key_id] + '</option>';
                        }
                    }
                }
                html_id_vehicle += '</select>';

                jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('.ovacrs-package-span').empty();
                jQuery(thisItem).children('.sub-item').children('.ovacrs-package').css('display', 'block');
                jQuery(thisItem).children('.sub-item').children('.rental_item').children('.ovacrs_amoun_insurance').val(ovacrs_amount_insurance);

                jQuery(thisItem).children('.sub-item').children('.ovacrs-id-vehicle').children('.ovacrs-id-vehicle-span').html(html_id_vehicle);
                if ( flag_package ) {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('label').text('Package');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('.ovacrs-package-span').html(html_pentime);

                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').css('display', 'none');

                }
            },
        })
    });

}) 

jQuery( '.insert_wrap_item' ).on('click',function(e){
    e.preventDefault();
    var html = jQuery(this).data('row');
    jQuery(this).closest('.wrap').find('.wrap_item').append(html);
    // Init Datetimepicker
    choosetime();

    //view total cost
    jQuery('.ovacrs-order .view_total_cost').on('click',function() {
        var thisItem = jQuery(this).closest('.item');

        var id_product = jQuery(thisItem).find('.ovacrs_name_product').val();
        var start_date = jQuery(thisItem).find('.ovacrs_start_date').val();
        var end_date = jQuery(thisItem).find('.ovacrs_end_date').val();

        var symbol = jQuery(this).data('symbol');
        var rental_type = jQuery(thisItem).find('#ovacrs-rental-type').val();

        var id_package = '';
        if( rental_type == 'period_time' ) {
             var id_package = jQuery(thisItem).find('#ovacrs-package').val();
        }

        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'none');

        jQuery.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: ({
                action: 'ovacrs_get_total_price_and_quantity',
                id_product: id_product,
                start_date: start_date,
                end_date: end_date,
                id_package: id_package,
            }),
            success: function(response){

                var data = jQuery.parseJSON(response);
                var error = data.error;

                if( ! error ) {
                    var quantity = data.quantity;
                    var line_total = data.line_total;
                    var product_price = data.product_price;

                    jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'block');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'block');

                    jQuery(thisItem).find('#ovacrs-price-detail').val(product_price);
                    jQuery(thisItem).find('#ovacrs-ovacrs-total-time').val(quantity);
                    jQuery(thisItem).find('#ovacrs-total-product').val(line_total);

                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'inline-block');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-error').children('.ovacrs-error-span').text(data.message);
                }                
                
            },
        })

    });

    
    jQuery('.ovacrs-order .ovacrs_name_product').on('change',function() {
        var name_product = jQuery(this).val();
        var thisItem = jQuery(this).parent('.rental_item').parent('.sub-item').parent('.item');
        var symbol = jQuery(this).data('symbol');

        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-time').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-total-cost').css('display', 'none');
        jQuery(thisItem).children('.sub-item').children('.ovacrs-error').css('display', 'none');

        if( name_product ) {
            jQuery(thisItem).children('.sub-item.ovabrw-meta').css('display', 'block');
        } else {
            jQuery(thisItem).children('.sub-item.ovabrw-meta').css('display', 'none');
        }
        
        jQuery.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: ({
                action: 'ovacrs_load_data_product_create_order',
                name_product: name_product,
            }),
            success: function(response){
                var data = jQuery.parseJSON(response);

                var rental_type = data.rental_type;
                var petime_id_arr = data.petime_id;
                var id_vehicles_arr = data.ovacrs_id_vehicles;
                var ovacrs_amount_insurance = data.ovacrs_amount_insurance;
                var product_price = data.product_price;

                jQuery(thisItem).find('#ovacrs-price-detail').val(product_price + ' ' + symbol);

                jQuery(thisItem).children('.sub-item').children('.rental_type').children("select").children("option[value='"+rental_type+"']").attr('selected', 'selected');

                var flag_package = false;
                var html_id_vehicle = '';
                var html_pentime = '';
                html_pentime += '<select id="ovacrs-package" class="select_ovacrs_package" name="ovacrs_package[]">';
                if ( rental_type === 'period_time' && petime_id_arr ) {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-dropoff').css('display', 'none');
                    flag_package = true;
                    for (let key in petime_id_arr){
                        if ( petime_id_arr.hasOwnProperty( key ) ) {
                            html_pentime += '<option value="' + petime_id_arr[key] + '">' + petime_id_arr[key] + '</option>';
                        }
                    }
                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-dropoff').css('display', 'block');
                }
                html_pentime += '</select>';

                html_id_vehicle += '<select id="ovacrs-id-vehicle" class="select_ovacrs_id_vehicle" name="ovacrs_id_vehicle[]">';
                if ( id_vehicles_arr ) {
                    for (let key_id in id_vehicles_arr){
                        if ( id_vehicles_arr.hasOwnProperty( key_id ) ) {
                            html_id_vehicle += '<option value="' + id_vehicles_arr[key_id] + '">' + id_vehicles_arr[key_id] + '</option>';
                        }
                    }
                }
                html_id_vehicle += '</select>';

                jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('.ovacrs-package-span').empty();
                jQuery(thisItem).children('.sub-item').children('.ovacrs-package').css('display', 'block');
                jQuery(thisItem).children('.sub-item').children('.rental_item').children('.ovacrs_amoun_insurance').val(ovacrs_amount_insurance);

                jQuery(thisItem).children('.sub-item').children('.ovacrs-id-vehicle').children('.ovacrs-id-vehicle-span').html(html_id_vehicle);
                if ( flag_package ) {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('label').text('Package');
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').children('.ovacrs-package-span').html(html_pentime);

                } else {
                    jQuery(thisItem).children('.sub-item').children('.ovacrs-package').css('display', 'none');

                }
            },
        })
    });
});

jQuery( '#booking-filter' ).on('click', '.delete_order', function(e){
    e.preventDefault();
    jQuery(this).closest('.ovacrs-order').remove();
});
