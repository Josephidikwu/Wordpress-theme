<?php
if ( ! function_exists('get_list_product_form_f')) {
	function get_list_product_form_f ( $args ) {
		$total = isset($args['total']) ? $args['total'] : 20;
		$order = isset($args['order']) ? $args['order'] : 'DESC';
		$id_submit = isset($args['id_submit']) ? $args['id_submit'] : "ova-submit-product";
		$query = new WP_Query( $args );
		$args_product = array(
			'post_type'      => 'product',
			'posts_per_page' => $total,
			'orderby' => 'title',
			'order' => $order
		);

		$wp_product = new \WP_Query($args_product);
		$html = '';
		$html .='<div class="ova-list-product-rental">';
		$html .= '<div class="wp-content">';
		$html .= '<div class="wp-title">';
		$html .= '<ul class="title-product" data-top="0">';
		$html_2 = '';

		while ( $wp_product->have_posts() ) : $wp_product->the_post();
			$html .= '<li ><a data-id="'.esc_attr(get_the_id()).'" href="javascript:void(0)">'.esc_html(get_the_title()) .'</a></li>';

			global $product;
			$is_produc_type = $product->is_type('ovacrs_car_rental') ? true : false ;
			$ovacrs_features_desc = get_post_meta( get_the_id(), 'ovacrs_features_desc', true );
			$ovacrs_features_label = get_post_meta( get_the_id(), 'ovacrs_features_label', true );

			$img  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
			$img_product = (!empty($img)) ? '<img class="image" src="'.$img.'"/>' : '';
			
			$html_2 .= '<div class="item"  id="ova-product-'.esc_attr(get_the_id()).'">';
			$html_2 .= '<div class="ova-media">';
			$html_2 .= $img_product;
			$html_2 .= '</div>';
			$html_2 .= '<div class="content">';
			$html_2 .= '<ul class="ova-feature-product">';
			if( $is_produc_type ){
				$html_2 .= '<li class="ova-renttime">';
				if( ovacrs_get_price_type( get_the_id() ) == 'day' ){
					$html_2 .= '<span class="amount">'.ovacrs_get_price_day( get_the_id() ).'</span>';
					$html_2 .= '<span class="time">'.esc_html__( '/ Day', 'ireca' ).'</span>' ;
				}else if( ovacrs_get_price_type( get_the_id() ) == 'hour' ){
					$html_2 .= '<span class="amount">'.ovacrs_get_price_hour( get_the_id() ).'</span>';
					$html_2 .= '<span class="time">'.esc_html__( '/ Hour', 'ireca' ).'</span>';
				}else if( ovacrs_get_price_type( get_the_id() ) == 'mixed' ) {
					$html_2 .= '<span class="amount">'.ovacrs_get_price_day( get_the_id() ).'</span>';
					$html_2 .= '<span class="time">'.esc_html__( '/ Day', 'ireca' ).'</span>';
				}else if( ovacrs_get_price_type( get_the_id() ) == 'period_time' ) {
					$html_2 .= '<span class="amount">'.esc_html__( 'Price Option', 'ireca' ).'</span>';
				}
				$html_2 .= "</li>";
			}else{

				$html_2 .= '<li class="ova-renttime">' . $product->get_price_html() . '</li>';

			}
			if (!empty($ovacrs_features_desc) && is_array($ovacrs_features_desc)) {
				
				foreach ($ovacrs_features_desc as $key => $value) { 			
					$html_2 .= '<li>';
					$html_2 .= '<label>'.esc_html( $ovacrs_features_label[$key] ) .': </label>';
					$html_2 .= '<span>'.esc_html( $ovacrs_features_desc[$key] ).'</span>';
					$html_2 .= '</li>';
				} 
			}
			$html_2 .= '</ul>';
			$html_2 .= '<a href="#'.$id_submit.'" class="ova-button-submit-rental" data-id="'.get_the_id().'" class="product-submit">'.esc_html( 'Book Now', 'ireca' ).'</a>';
			$html_2 .= '</div>';//end content
			$html_2 .= '</div>';//end itemt
		endwhile;wp_reset_postdata();
		$html .= '</ul>';
		$html .= '</div>';
		$html .= '<div class="ova-list-detail">';
		$html .= $html_2;
		$html .='</div>';//end ova-list-detail
		$html .='</div>';//end wp-content
		$html .= '<div class="control"><a href="javascript:void(0)" id="ova-up"><i class="fa fa-chevron-up" ></i></a><a href="javascript:void(0)" id="ova-down"><i class="fa fa-chevron-down" ></i></a></div>';
		$html .= '</div>';
		return $html;
	}
}
add_shortcode( 'get_list_product_form', 'get_list_product_form_f' );
?>