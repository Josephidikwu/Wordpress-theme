<?php if ( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'Ajax_Process' ) ){
	class Ajax_Process{

		public function __construct(){
			add_action( 'wp_ajax_validate_form_booking', array( $this, 'validate_form_booking') );
			add_action( 'wp_ajax_nopriv_validate_form_booking', array( $this, 'validate_form_booking') );

			add_action( 'wp_ajax_get_package_period_time', array( $this, 'get_package_period_time') );
			add_action( 'wp_ajax_nopriv_get_package_period_time', array( $this, 'get_package_period_time') );

			add_action( 'wp_ajax_get_location_pickup', array( $this, 'get_location_pickup') );
			add_action( 'wp_ajax_nopriv_get_location_pickup', array( $this, 'get_location_pickup') );

			add_action( 'wp_ajax_get_location_dropoff', array( $this, 'get_location_dropoff') );
			add_action( 'wp_ajax_nopriv_get_location_dropoff', array( $this, 'get_location_dropoff') );

			add_action( 'wp_ajax_get_resource_product', array( $this, 'get_resource_product') );
			add_action( 'wp_ajax_nopriv_get_resource_product', array( $this, 'get_resource_product') );

			add_action( 'wp_ajax_get_choise_deposit', array( $this, 'get_choise_deposit') );
			add_action( 'wp_ajax_nopriv_get_choise_deposit', array( $this, 'get_choise_deposit') );

			add_action( 'wp_ajax_get_custom_checkout_field_product', array( $this, 'get_custom_checkout_field_product') );
			add_action( 'wp_ajax_nopriv_get_custom_checkout_field_product', array( $this, 'get_custom_checkout_field_product') );

		}

		public function validate_form_booking() {

			global $woocommerce;
			$product_id = $_POST['product_id'];
			$passed = true;
			$passed= ovacrs_validation_booking_form($passed);

			$data = [];
			if ($passed) {
				WC()->session->set( 'wc_notices', array() );
				$woocommerce->cart->add_to_cart( $product_id );
				$data['validate'] = 1;
			} else {
				$data['validate'] = 0;
				$data = array_merge($data,wc_get_notices());
			}
			$data = json_encode($data);
			echo $data;
			wp_die();
		}

		public function get_location_pickup() {
			$product_id = $_POST['product_id'];
			$rental_type = $_POST['rental_type'];

			$html = '<span class="input-addon"><i class="fa fa-map-marker" ></i> '.esc_html__("Pick-up", "ireca"). '</span>';
			if( $rental_type !== 'transportation' ) {
				$html .= ovacrs_get_locations_html( $class = 'ovacrs_pickup_loc', $required = 'required', $selected = '', 'Select Location', $product_id ); 
			} else {
				$html .= ovacrs_get_locations_transport_html( $class = 'ovacrs_pickup_loc', $required = 'required', $selected = '', $product_id, 'pickup' );
			}
			echo $html;
			// $html .= 
			wp_die();
		}


		public function get_location_dropoff() {
			$product_id = $_POST['product_id'];
			$rental_type = $_POST['rental_type'];

			$html = '<span class="input-addon"><i class="fa fa-map-marker" ></i> '.esc_html__("Drop-off", "ireca"). '</span>';
			if( $rental_type !== 'transportation' ) {
				$html .= ovacrs_get_locations_html( $class = 'ovacrs_pickoff_loc', $required = 'required', $selected = '', 'Select Location', $product_id ); 
			} else {
				$html .= ovacrs_get_locations_transport_html( $class = 'ovacrs_pickoff_loc', $required = 'required', $selected = '', $product_id, 'dropoff' );
			}
			echo $html;
			// $html .= 
			wp_die();
		}

		public function get_package_period_time () {
			$product_id = $_POST['product_id'];
			$rental_type = $_POST['rental_type'];


			$hour_default = get_theme_mod( 'rd_bf_hour_default', '09:00' ); 
			$time_step = get_theme_mod( 'rd_bf_time_step', '30' );
			$dateformat = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
			$timeformat = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

			$ovacrs_petime_id = get_post_meta( $product_id, 'ovacrs_petime_id', true );
			$ovacrs_petime_label = get_post_meta( $product_id, 'ovacrs_petime_label', true );

			$html = '';
			$html .= '<span class="input-addon"><i class="fa fa-calendar"></i>'.esc_html__('Package','ireca').'</span>';

			if ($rental_type == "period_time") {
				$html .= '<select name="ovacrs_period_package_id" class="required">';
				$html .= '<option value=""></option>';
				if( $ovacrs_petime_id ){ 
					foreach ($ovacrs_petime_id as $key => $value) { 
						if( isset( $ovacrs_petime_id[$key] ) && isset( $ovacrs_petime_label[$key] ) ) 
							$html .= '<option value="'.trim( $ovacrs_petime_id[$key] ) .'" > '. $ovacrs_petime_label[$key] .' </option>';
					} 
				}
				$html .= '</select>';
			}

			$result =substr($html, 0, -1);

			echo $result;

		}

		public function get_resource_product () {
			$product_id = $_POST['product_id'];
			$ovacrs_resource_name = get_post_meta( $product_id, 'ovacrs_resource_name', true ); 
			$html = '';
			if( $ovacrs_resource_name ){

				$ovacrs_resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true ); 
				$ovacrs_resource_duration_val = get_post_meta( $product_id, 'ovacrs_resource_duration_val', true ); 
				$ovacrs_resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true ); 
				$ovacrs_resource_id = get_post_meta( $product_id, 'ovacrs_resource_id', true ); 

				foreach ($ovacrs_resource_name as $key => $value) {
					$dur_type = '';
					switch ($ovacrs_resource_duration_type[$key]) {
						case 'hours':
							$dur_type = esc_html__('Hour(s)', 'ireca');
							break;
						case 'days':
							$dur_type = esc_html__('Day(s)', 'ireca');
							break;
						case 'total':
							$dur_type = esc_html__('Total', 'ireca');
							break;
					}

					$html .= '<div class="item-resource">';
					$html .= '<div class="left">';
					$html .= '<input key="'.$ovacrs_resource_id[$key].'" type="checkbox" name="ovacrs_resource_checkboxs['.esc_attr( $ovacrs_resource_id[$key] ).']" id="'.esc_attr( $ovacrs_resource_name[$key] ).'" value="'.esc_attr( $ovacrs_resource_name[$key] ).'" >';
					$html .= '<label for="'.esc_attr( $ovacrs_resource_name[$key] ).'">'.esc_html( $ovacrs_resource_name[$key] );
					$html .= '</div>';

					$html .= '<div class="right">';
					$html .= '<span class="dur_price">'.wc_price( $ovacrs_resource_price[$key] ).'</span>';
					$html .= '<span class="slash">/</span>';
					$html .= '<span class="dur_val">'.esc_html( $ovacrs_resource_duration_val[$key] ).'</span>';
					$html .= '<span class="dur_type">'.$dur_type.'</span>';

					$html .= '</div>';

					$html .= '</div>';
				}

			}
			echo $html;
		}

		public function get_choise_deposit () {
			$product_id = $_POST['product_id'];

			$deposit_force = get_post_meta ( $product_id, 'ovacrs_force_deposit', true );
			$deposit_type_deposit = get_post_meta ( $product_id, 'ovacrs_type_deposit', true );
			$value_deposit = get_post_meta ( $product_id, 'ovacrs_amount_deposit', true );

			$cursor = $disable = '';
			if ($deposit_force === 'yes') {
				$cursor = 'cursor: pointer';
			} else {
				$disable =  'disabled';
			}



			$html = '';
			$deposit_enable = get_post_meta ( $product_id, 'ovacrs_enable_deposit', true );
			if ( $deposit_enable === 'yes' ) {
				$html .= '<div class="ovacrs-deposit">';
				$html .= '<div class="title-deposite">';
				$html .= '<span >'. esc_html__("Deposit Option", "ireca").'</span>';
				if ($deposit_type_deposit === 'percent') {
					$html .= '<span >'.esc_html($value_deposit) .'%</span>';
				} else {
					$html .= '<span class="">'. wc_price($value_deposit) .'</span>';
				}
				$html .= '<span class="">'.esc_html__('Per item', 'ireca').'</span>';
				$html .= '</div>';
				$html .= '<div class="ovacrs-type-deposit">';
				$html .= '<input type="radio" id="ovacrs-pay-deposit" name="ova_type_deposit" value="deposit" checked />';
				$html .= '<label style="'.esc_attr($cursor) .'" for="ovacrs-pay-deposit">'.esc_html__('Pay Deposit', 'ireca').'</label>';
				$html .= '<input type="radio" id="ovacrs-pay-full" name="ova_type_deposit" value="full" '.esc_attr($disable) .' />';
				$html .= '<label style="'.esc_attr($cursor).'" for="ovacrs-pay-full">'.esc_html__('Full Amount', 'ireca') .'</label>';
				$html .= '</div>';
				$html .= '</div>';
			}
			echo $html;
			
		}

		// Get custom checkout field
		public function get_custom_checkout_field_product(){

			$product_id = $_POST['product_id'];

			$list_ckf_output = ovacrs_get_list_field_checkout( $product_id );

			$html = '';
			
			if( is_array( $list_ckf_output ) && ! empty( $list_ckf_output ) ) {

				foreach( $list_ckf_output as $key => $field ) {

					if( array_key_exists('enabled', $field) &&  $field['enabled'] == 'on' ) {

						if( array_key_exists('required', $field) &&  $field['required'] == 'on' ) {
							$class_required = 'required';
						} else {
							$class_required = '';
						}
						

						$html .= '<label>'.$field['label'].'</label>';
						$html .= '<div class="ovacrs_'.$key.'"></div>';

						if( $field['type'] !== 'textarea' && $field['type'] !== 'select' ) {
							$html .= '<input type="'.$field['type'].'" name="'.$key.'"  class=" custom_ck_field '.$field['class'].' '.$class_required.'" placeholder="'.$field['placeholder'].'"   value="'.$field['default'].'" data-error=".ovacrs_'. $key.'"  />';
						}

						if( $field['type'] === 'textarea' ) {
							$html .= '<textarea name="'.$key.'"  class=" custom_ck_field '.$field['class'].' '. $class_required. '" placeholder="'.$field['placeholder'].'"   value="'.$field['default'].'" cols="10" rows="5"></textarea>';
						}

						if( $field['type'] === 'select' ) { 

							$ova_options_key = $ova_options_text = [];
							if( array_key_exists( 'ova_options_key', $field ) ) {
								$ova_options_key = $field['ova_options_key'];
							}

							if( array_key_exists( 'ova_options_text', $field ) ) {
								$ova_options_text = $field['ova_options_text'];
							}
							
							$html .= '<select name="'. $key.'"  class=" custom_ck_field '.$field['class'].' '. $class_required. '" >';
								

								if( ! empty( $ova_options_text ) && is_array( $ova_options_text ) ) { 
									foreach( $ova_options_text as $key => $value ) { 
										$selected = '';
										if( $ova_options_key[$key] == $field['default'] ) {
											$selected = 'selected';
										}
										
										$html .= '<option '.$selected.' value="'.$ova_options_key[$key] .'">'.$value.'</option>';
								

									}
								}
							
								
							$html .= '</select>';
						}

						$html .= '<br/><br/><div class="error">'.esc_html__( 'Please input data', 'ova-crs' ).'</div>';

					
				
					}//endif
				}//end foreach
			}//end if

			echo $html;

		}



	}
	new Ajax_Process();
}
?>