<?php

namespace Ireca\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ovacrs_booking_form_request extends Widget_Base {



	public function get_name() {
		return 'ovacrs_booking_form_request';
	}

	public function get_title() {
		return __( 'Request Booking Form', 'ireca' );
	}

	public function get_icon() {
		return 'fa fa-map-marker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'ireca-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ireca' ),
				
			]
		);

		$cat_args = array(
			'orderby' => 'name',
			'order' => 'ASC'
		);

		$product_categories = get_terms( 'product_cat', $cat_args );

		$product_cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($product_categories) {
			foreach ( $product_categories as $cate ) {
				$product_cate_array[$cate->slug] = $cate->name;
			}
		} else {
			$product_cate_array["all"] = "No content Category found";
		}
		if (!isset($product_cate_array["no-cat"])) {
			$product_cate_array = array_merge($arrayCateAll,$product_cate_array);
		}

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ireca' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'Request Booking Vehicle', 'ireca' ),
			]
		);

		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'ireca' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => $product_cate_array,
			]
		);

		$this->add_control(
			'total_count',
			[
				'label' => __( 'Total Product', 'ireca' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5,
			]
		);

		$this->add_control(
			'order_by',
			[
				'label' => __('Order By', 'ireca'),
				'type' => Controls_Manager::SELECT,
				'default' => 'ID',
				'options' => [
					'ID' => __('ID', 'ireca'),
					'author' => __('Author', 'ireca'),
					'title' => __('Title', 'ireca'),
					'date' => __('Date Created', 'ireca'),
					'modified' => __('Date Modified', 'ireca'),
				]
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __('Order', 'ireca'),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __('ASC', 'ireca'),
					'desc' => __('DESC', 'ireca'),
				]
			]
		);

		$this->add_control(
			'show_extra_resource',
			[
				'label' => __( 'Show Extra resource', 'ireca' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'ireca' ),
				'label_off' => __( 'Hide', 'ireca' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'text_submit',
			[
				'label' => __( 'Text Submit', 'ireca' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Reserve Now', 'ireca' ),
			]
		);
		


		$this->end_controls_section();

	}


	function ovacrs_get_locations_html( $name = '', $required = 'required', $selected = '' ){
		

		$html = '<select name="'.$name.'" class="'.$required.'">
		<option value="">'. esc_html__('Select Location', 'ireca').'</option>';
		if($locations->have_posts() ) : while ( $locations->have_posts() ) : $locations->the_post();
			global $post;
			$active = ( trim( get_the_title() ) === trim( $selected ) ) ? 'selected="selected"' : '';
			$html .= '<option value="'.get_the_title().'" '.$active.'>'.get_the_title().'</option>';
		endwhile; endif;wp_reset_postdata();
		$html .= '</select>';

		return $html;


	}

	protected function render() {
		$settings = $this->get_settings();

		$cat_slug = $settings['category'];
		$cat_slug = $cat_slug !== "all" ? $cat_slug : "";


		
		$args_product = array(
			'post_type'      => 'product',
			'tax_query' => array(
				array(
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => 'ovacrs_car_rental', 
				),
			),
			'posts_per_page' => $settings['total_count'],
			'product_cat'    => $cat_slug,
			'orderby' => $settings['order_by'],
			'order' => $settings['order']
		);
		
		$wp_product = new \WP_Query($args_product);

		$locations = new \WP_Query(
			array(
				'post_type' => 'location',
				'post_status' => 'publish',
				'posts_per_page' => '-1'
			)
		);

		$ovacrs_rental_type = $list_title_product = [];
		$class_require_loc = get_theme_mod( 'use_loc_filter', 'true' ) == 'true' ? 'required' : '';

		$show_number = get_theme_mod( 'rd_rbf_show_number', 'true' );
		$show_address = get_theme_mod( 'rd_rbf_show_address', 'true' );
		$show_pickup = get_theme_mod( 'rd_rbf_show_pickup_loc', 'true' );
		$show_pickoff = get_theme_mod( 'rd_rbf_show_pickoff_loc', 'true' );
		$show_quantity = get_theme_mod( 'rd_rbf_show_quantity', 'true' );

		?>
		<div class="ova-booking-form-request">
			<div class="wp-ova-booking-form-request">
				<div class="ireca_loadding">
					<div class="loadingspinner"></div>
				</div>
				<?php if( $settings['title'] ){ ?>
					<h2><?php echo $settings['title']; ?></h2>
				<?php } ?>

				<form class="form-booking wrap_fields" id="ova_booking_form_request" action="<?php echo home_url('/'); ?>" method="post" enctype="multipart/form-data" >
					<div class="ova-input">
						<div class="input">
							<span class="input-addon"><i class="fa fa-car" ></i> <?php esc_html_e("Product", "ireca") ?></span>
							<select name="product" id="ova-select-product-booking-request" class="required">
								<option value="" selected="selected"><?php esc_html_e("Select product", "ireca") ?></option>
								<?php
								while ( $wp_product->have_posts() ) : $wp_product->the_post();
									$ovacrs_rental_type[get_the_id()] = get_post_meta( get_the_id(), 'ovacrs_price_type', true );
									$list_title_product[get_the_id()] = get_the_title();
									?>
									<option value="<?php echo esc_attr(get_the_id()) ?>"><?php echo esc_html(get_the_title()) ?></option>
									<?php
								endwhile;
								wp_reset_query();
								?>
							</select>
						</div>
						<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>

					<div class="ova-input">
						<div class="input">
							<span class="input-addon"><i class="fa fa-user" ></i> <?php esc_html_e("Name", "ireca") ?></span>
							<input type="text" class="required" name="name" placeholder="<?php esc_html_e( 'John Doe', 'ireca' ); ?> ">
						</div>
						<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>

					<div class="ova-input">
						<div class="input">
							<span class="input-addon"><i class="far fa-envelope" ></i> <?php esc_html_e("Email", "ireca") ?></span>
							<input type="text" class="required" name="email" placeholder="<?php esc_html_e( 'sample@yourcompany.com', 'ireca' ); ?> ">
						</div>
						<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>
					<?php if ($show_number == 'true') : ?>
						<div class="ova-input">
							<div class="input">
								<span class="input-addon"><i class="fa fa-phone" ></i> <?php esc_html_e("Phone", "ireca") ?></span>
								<input type="text" class="required" name="number" placeholder="<?php esc_html_e( '+66-4545688', 'ireca' ); ?> ">
							</div>
							<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
						</div>
					<?php endif ?>

					<?php if ($show_address == 'true') : ?>
						<div class="ova-input">
							<div class="input">
								<span class="input-addon"><i class="fa fa-map-pin" ></i> <?php esc_html_e("Address", "ireca") ?></span>
								<input type="text" class="required" name="address" placeholder="<?php esc_html_e( 'Address', 'ireca' ); ?> ">
							</div>
							<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
						</div>
					<?php endif ?>

					<?php if ($show_pickup == 'true') : ?>
						<div class="ova-input">
							<div class="input ovacrs-pickup-loc">
								<span class="input-addon"><i class="fa fa-map-marker" ></i> <?php esc_html_e("Pick-up", "ireca") ?></span>
								<select name="ovacrs_pickup_loc" class="<?php echo esc_attr( $class_require_loc ) ?>">
									<option value=""><?php esc_html_e('Select Location', 'ireca') ?></option>
									<?php 
									if($locations->have_posts() ) : while ( $locations->have_posts() ) : $locations->the_post();
										global $post;
										?>
										<option value="<?php echo esc_attr(get_the_title()) ?>" ><?php echo esc_html(get_the_title()) ?></option>
										<?php
									endwhile; endif;wp_reset_postdata();
									?>
								</select>
							</div>
							<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
						</div>
					<?php endif ?>

					<?php if ($show_pickoff == 'true') : ?>
						<div class="ova-input">
							<div class="input ovacrs-dropoff-loc">
								<span class="input-addon"><i class="fa fa-map-marker" ></i> <?php esc_html_e("Drop-off", "ireca") ?></span>
								<select name="ovacrs_pickoff_loc" class="<?php echo esc_attr( $class_require_loc ) ?>">
									<option value=""><?php esc_html_e('Select Location', 'ireca') ?></option>
									<?php 
									if($locations->have_posts() ) : while ( $locations->have_posts() ) : $locations->the_post();
										global $post;
										?>
										<option value="<?php echo esc_attr(get_the_title()) ?>" ><?php echo esc_html(get_the_title()) ?></option>
										<?php
									endwhile; endif;wp_reset_postdata();
									?>
								</select>
							</div>
							<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
						</div>
					<?php endif ?>
					<?php 	
					$start_time_default = "";
					$end_time_default = "";
					$hour_default = get_theme_mod( 'rd_bf_hour_default', '09:00' ); 
					$time_step = get_theme_mod( 'rd_bf_time_step', '30' );
					$dateformat = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
					$timeformat = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

					$array_time_format = [
						'hour_default' => $hour_default,
						'time_step' => $time_step,
						'dateformat' => $dateformat,
						'timeformat' => $timeformat
					];

					$lang = get_theme_mod( 'calendar_layout', 'en' ); 
					$calendar_dis_weekend = get_theme_mod( 'calendar_dis_weekend', '0,6' );
					$cal_time = get_theme_mod( 'calendar_time', '07:00, 07:30, 08:00, 08:30, 09:00, 09:30, 10:00, 10:30, 11:00, 11:30, 12:00, 12:30, 13:00, 13:30, 14:00, 14:30, 15:00, 15:30, 16:00, 16:30, 17:00, 17:30, 18:00' );

					?>


					<div class="ova-input">
						<div class="input ova-pickup">
							<span class="input-addon"><i class="fa fa-calendar"></i> <?php esc_html_e("Pick-up", "ireca") ?></span>
							<input type="text" 
								id="ova-pickup-form-booking-request" 
								onkeydown="return false" 
								name="pickup_date" 
								data-hour_default="<?php echo esc_attr( $hour_default ); ?>" 
								data-time_step="<?php echo esc_attr( $time_step ); ?>"   
								data-dateformat="<?php echo esc_attr( $dateformat ); ?>" 
								data-timeformat="<?php echo esc_attr( $timeformat ); ?>" 
								class="required ovacrs_datetimepicker" 
								placeholder="<?php echo esc_attr( $dateformat ); ?>" 
								autocomplete="off" value="<?php echo $start_time_default; ?>" 
								data-error=".ovacrs_pickup_date" 
								onfocus="blur();" 
								data-lang="<?php echo esc_attr( $lang ); ?>" 
								data-time="<?php echo esc_attr( $cal_time ); ?>" 
								data-disweek="<?php echo esc_attr($calendar_dis_weekend); ?>"
								/>
						</div>
						<div class="error"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>
					<div class="ova-input">
						<div class="input ova-package"></div>
						<div class="error package"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>
					<div class="ova-input">
						<div class="input ova-dropoff">
							<span class="input-addon"><i class="fa fa-calendar"></i> <?php esc_html_e("Drop-off", "ireca") ?></span>
							<input type="text" 
								name="pickoff_date" 
								onkeydown="return false"  
								data-hour_default="<?php echo esc_attr( $hour_default ); ?>" 
								data-time_step="<?php echo esc_attr( $time_step ); ?>" 
								data-dateformat="<?php echo esc_attr( $dateformat ); ?>" 
								data-timeformat="<?php echo esc_attr( $timeformat ); ?>" 
								class="required ovacrs_datetimepicker" 
								placeholder="<?php echo esc_attr( $dateformat ); ?>"   
								autocomplete="off" 
								value="<?php echo $end_time_default; ?>" 
								data-error=".ovacrs_pickoff_date" 
								onfocus="blur();" 
								data-lang="<?php echo esc_attr( $lang ); ?>" 
								data-time="<?php echo esc_attr( $cal_time ); ?>" 
								data-disweek="<?php echo esc_attr($calendar_dis_weekend); ?>"
								/>
						</div>
						<div class="error dropoff"><?php esc_html_e('Please input data', 'ireca') ?></div>
					</div>

					<?php if ( $show_quantity == 'true' ): ?>
						<div class="ova-input ">
							<div class="input">
								<span class="input-addon"><i class="far fa-plus-square"></i> <?php esc_html_e("Quantity", "ireca") ?></span>
								<input type="number" name="ovacrs_quantity" value="1" min="1" />
							</div>
						</div>
					<?php endif; ?>

					<div class="ova-input ">
						<div data-show-extra-resource="<?php echo esc_attr($settings['show_extra_resource']) ?>" class="input extra-resource">
						</div>
					</div>

					<div class="ova-input">
						<div class="input">
							<div class="custom-checkout-fields"></div>
						</div>
					</div>


					<input type="hidden" id="list_rental_type_request" name="list_rental_type" value="<?php echo esc_attr(json_encode($ovacrs_rental_type)) ?>" />
					<input type="hidden" id="list_title_product" name="list_title_product" value="<?php echo esc_attr(json_encode($list_title_product)) ?>" />

					<input type="hidden" name="product_name" id="product_name_request" value="" />
					<input type="hidden" name="product_id" id="product_id_request" value="" />

					<input type="hidden" name="request_booking" value="request_booking" />

					<button type="submit" id="ova_booking_form_request" class="submit btn_tran"><?php echo esc_html( $settings['text_submit'] ); ?></button>
				</form>
			</div>
		</div>
		<?php

	}
// end render
}


