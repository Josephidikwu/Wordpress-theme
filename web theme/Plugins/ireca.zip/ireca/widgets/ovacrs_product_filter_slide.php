<?php

namespace Ireca\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ovacrs_product_filter_slide extends Widget_Base {



	public function get_name() {
		return 'ovacrs_product_filter_slide';
	}

	public function get_title() {
		return __( 'Product Filter Slide', 'ireca' );
	}

	public function get_icon() {
		return 'fa fa-sliders';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'ireca-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ireca' ),
				
			]
		);

		$cat_args = array(
			'orderby' => 'name',
			'order' => 'ASC'
		);

		$product_categories = get_terms( 'product_cat', $cat_args );

		$product_cate_array = array();
		$arrayCateAll = array( 'all' => 'All categories ' );
		if ($product_categories) {
			foreach ( $product_categories as $cate ) {
				$product_cate_array[$cate->slug] = $cate->name;
			}
		} else {
			$product_cate_array["all"] = "No content Category found";
		}
		if (!isset($product_cate_array["no-cat"])) {
			$product_cate_array = array_merge($arrayCateAll,$product_cate_array);
		}


		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'ireca' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'all',
				'options' => $product_cate_array,
			]
		);

		$this->add_control(
			'total_count',
			[
				'label' => __( 'Total Product', 'ireca' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 10,
			]
		);

		$this->add_control(
			'number_product_display',
			[
				'label' => __( 'Number Product Display', 'ireca' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 8,
			]
		);

		$this->add_control(
			'order_by',
			[
				'label' => __('Order By', 'ireca'),
				'type' => Controls_Manager::SELECT,
				'default' => 'ID',
				'options' => [
					'ID' => __('ID', 'ireca'),
					'author' => __('Author', 'ireca'),
					'title' => __('Title', 'ireca'),
					'date' => __('Date Created', 'ireca'),
					'modified' => __('Date Modified', 'ireca'),
				]
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __('Order', 'ireca'),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __('ASC', 'ireca'),
					'desc' => __('DESC', 'ireca'),
				]
			]
		);

		$this->add_control(
			'height_image',
			[
				'label' => __( 'Height Image Product', 'ireca' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova-list-product-rental .wp-content .ova-list-detail .item .ova-media' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_submit',
			[
				'label' => __( 'Text Submit', 'ireca' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Book Now', 'ireca' ),
			]
		);

		$this->add_control(
			'scroll_to',
			[
				'label' => __('Scroll to', 'ireca'),
				'type' => Controls_Manager::SELECT,
				'default' => 'bk_form',
				'options' => [
					'bk_form' => __('Booking Form', 'ireca'),
					'rbk_form' => __('Request Booking Form', 'ireca'),
				]
			]
		);
		


		$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings();

		$cat_slug = $settings['category'];
		$cat_slug = $cat_slug !== "all" ? $cat_slug : "";


		
		$args_product = array(
			'post_type'      => 'product',
			'tax_query' => array(
				array(
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => 'ovacrs_car_rental', 
				),
			),
			'posts_per_page' => $settings['total_count'],
			'product_cat'    => $cat_slug,
			'orderby' => $settings['order_by'],
			'order' => $settings['order']
		);
		
		$wp_product = new \WP_Query($args_product);

		$height_wp_title = $settings['number_product_display'] * 57;

		?>
		<div class="ova-product-filter-slide">
			<?php
			$html = '';
			$html .='<div class="ova-list-product-rental">';
			$html .= '<div class="wp-content">';
			$html .= '<div class="wp-filter">';
			$html .= '<div class="wp-title" style="height:'.$height_wp_title.'px" data-number-product="'.$settings['number_product_display'].'">';
			$html .= '<ul class="title-product" data-top="0">';
			$html_2 = '';

			while ( $wp_product->have_posts() ) : $wp_product->the_post();
				$html .= '<li ><a data-id="'.esc_attr(get_the_id()).'" href="javascript:void(0)">'.esc_html(get_the_title()) .'</a></li>';

				global $product;
				$is_produc_type = $product->is_type('ovacrs_car_rental') ? true : false ;
				$ovacrs_features_desc = get_post_meta( get_the_id(), 'ovacrs_features_desc', true );
				$ovacrs_features_label = get_post_meta( get_the_id(), 'ovacrs_features_label', true );

				$img  = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
				$img_bg = (!empty($img)) ? 'style="background-image:url('.$img.')"' : '';

				$html_2 .= '<div class="item"  id="ova-product-'.esc_attr(get_the_id()).'">';
				$html_2 .= '<div class="ova-media" ' . $img_bg . '>';
				$html_2 .= '</div>';
				$html_2 .= '<div class="content">';
				$html_2 .= '<ul class="ova-feature-product">';
				if( $is_produc_type ){
					$html_2 .= '<li class="ova-renttime">';
					if( ovacrs_get_price_type( get_the_id() ) == 'day' ){
						$html_2 .= '<span class="amount">'.ovacrs_get_price_day( get_the_id() ).'</span>';
						$html_2 .= '<span class="time">'.esc_html__( '/ Day', 'ireca' ).'</span>' ;
					}else if( ovacrs_get_price_type( get_the_id() ) == 'hour' ){
						$html_2 .= '<span class="amount">'.ovacrs_get_price_hour( get_the_id() ).'</span>';
						$html_2 .= '<span class="time">'.esc_html__( '/ Hour', 'ireca' ).'</span>';
					}else if( ovacrs_get_price_type( get_the_id() ) == 'mixed' ) {
						$html_2 .= '<span class="amount">'.ovacrs_get_price_day( get_the_id() ).'</span>';
						$html_2 .= '<span class="time">'.esc_html__( '/ Day', 'ireca' ).'</span>';
					}else if( ovacrs_get_price_type( get_the_id() ) == 'period_time' || ovacrs_get_price_type( get_the_id() ) == 'transportation' ) {
						$html_2 .= '<span class="amount">'.esc_html__( 'Price Option', 'ireca' ).'</span>';
					}
					$html_2 .= "</li>";
				}else{

					$html_2 .= '<li class="ova-renttime">' . $product->get_price_html() . '</li>';

				}
				if (!empty($ovacrs_features_desc) && is_array($ovacrs_features_desc)) {

					foreach ($ovacrs_features_desc as $key => $value) { 			
						$html_2 .= '<li>';
						$html_2 .= '<label>'.esc_html( $ovacrs_features_label[$key] ) .': </label>';
						$html_2 .= '<span>'.esc_html( $ovacrs_features_desc[$key] ).'</span>';
						$html_2 .= '</li>';
					} 
				}
				$html_2 .= '</ul>';
				$html_2 .= '<a href="javascript:void(0)" data-scroll="'.esc_attr($settings['scroll_to']).'" class="ova-button-submit-rental" data-id="'.get_the_id().'" class="product-submit">'.esc_html( $settings['text_submit'] ).'</a>';
			$html_2 .= '</div>';//end content
			$html_2 .= '</div>';//end itemt
		endwhile;wp_reset_postdata();
		$html .= '</ul>';//end title-product
		$html .= '</div>';//end wp-title
		$html .= '<div class="control"><a href="javascript:void(0)" id="ova-up"><i class="fa fa-chevron-up" ></i></a><a href="javascript:void(0)" id="ova-down"><i class="fa fa-chevron-down" ></i></a></div>';
		$html .= '</div>';//end wp-filter
		$html .= '<div class="ova-list-detail">';
		$html .= $html_2;
			$html .='</div>';//end ova-list-detail
			$html .='</div>';//end wp-content
			
			$html .= '</div>';
			echo $html;
			?>
		</div>
		<?php

	}
// end render
}


