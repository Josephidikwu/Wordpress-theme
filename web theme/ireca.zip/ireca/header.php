<?php  $header = ireca_get_current_header(); 
	get_template_part( 'header', $header ); ?>
            