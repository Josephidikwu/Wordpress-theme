			
				<?php  $footer = ireca_get_current_footer();
						get_template_part( 'footer',$footer); 
				?>
			
		</div><!-- /container_boxed -->
		<?php wp_footer(); ?>
	</body><!-- /body -->
</html>