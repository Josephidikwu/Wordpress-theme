<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$post_id = get_the_id();
$deposit_force = get_post_meta ( $post_id, 'ovacrs_force_deposit', true );
$deposit_type_deposit = get_post_meta ( $post_id, 'ovacrs_type_deposit', true );
$value_deposit = get_post_meta ( $post_id, 'ovacrs_amount_deposit', true );

$cursor = $disable = '';
if ($deposit_force === 'yes') {
	$cursor = 'cursor: pointer';
} else {
	$disable =  'disabled';
}

?>
<div class="ovacrs-deposit">
	<div class="title-deposite">
		<span class=""><?php esc_html_e('Deposit Option', 'ireca') ?></span>
		
		<?php
			if ($deposit_type_deposit === 'percent') {
				?>
					<span class=""><?php echo esc_html($value_deposit) ?>%</span>
				<?php
			} elseif ($deposit_type_deposit === 'value') {
				?>
					<span class=""><?php echo wc_price($value_deposit) ?></span>
				<?php
			}

		?>
		<span class=""><?php esc_html_e('Per item', 'ireca') ?></span>
	</div>
	<div class="ovacrs-type-deposit">
		<input type="radio" id="ovacrs-pay-deposit" class="ovacrs-pay-deposit" name="ova_type_deposit" value="deposit" checked />
		<label style="<?php echo esc_attr($cursor) ?>" class="ovacrs-pay-deposit" for="ovacrs-pay-deposit"><?php esc_html_e('Pay Deposit', 'ireca') ?></label>

		<input type="radio" id="ovacrs-pay-full" class="ovacrs-pay-full" name="ova_type_deposit" value="full" <?php echo esc_attr($disable) ?> />
		<label style="<?php echo esc_attr($cursor) ?>" class="ovacrs-pay-full" for="ovacrs-pay-full"><?php esc_html_e('Full Amount', 'ireca') ?></label>
	</div>
	
</div>