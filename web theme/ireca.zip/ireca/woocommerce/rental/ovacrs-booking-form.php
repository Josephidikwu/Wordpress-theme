<?php 
	$post_id = get_the_id(); 
	$ovacrs_rental_type = get_post_meta( $post_id, 'ovacrs_price_type', true ); 

	$start_time_default = isset($_GET['start_time']) ? $_GET['start_time'] : '';
	$end_time_default = isset($_GET['end_time']) ? $_GET['end_time'] : '';

	$pickup_loc_default = isset($_GET['pickup_loc']) ? $_GET['pickup_loc'] : '';
	$drop_off_default = isset($_GET['drop_off']) ? $_GET['drop_off'] : '';

	$inventory = intval( get_post_meta( $post_id, 'ovacrs_car_count', true ) );


	$lang = get_theme_mod( 'calendar_layout', 'en' );
	$cal_time = get_theme_mod( 'calendar_time', '07:00, 07:30, 08:00, 08:30, 09:00, 09:30, 10:00, 10:30, 11:00, 11:30, 12:00, 12:30, 13:00, 13:30, 14:00, 14:30, 15:00, 15:30, 16:00, 16:30, 17:00, 17:30, 18:00' );
	$calendar_dis_weekend = get_theme_mod( 'calendar_dis_weekend', '0,6' );

?>
<div class="ireca_booking_form" id="ireca_booking_form">
	<h3 class="title"><?php esc_html_e( 'Booking Form', 'ireca' ); ?></h3>
	<form class="form" id="booking_form" action="<?php home_url('/'); ?>" method="post" enctype="multipart/form-data" data-mesg_required="<?php esc_html_e( 'This field is required.', 'ireca' ); ?>">

		<div class="row wrap_fields">
			
			<?php if( get_theme_mod( 'rd_bf_show_pickup_loc', 'true' ) == 'true' ){ ?>
				<div class="col-md-3 rb_field">
					<label><?php esc_html_e( 'Pick-up Location', 'ireca' ); ?></label>
					<?php

						if( $ovacrs_rental_type !== 'transportation' ) {
							echo ovacrs_get_locations_html( $class = 'ovacrs_pickup_loc', $required = 'required', $selected = $pickup_loc_default, esc_html__( 'Select Location', 'ova-crs' ) , $post_id ); 
						} else {
							echo ovacrs_get_locations_transport_html( $class = 'ovacrs_pickup_loc', $required = 'required', $selected = $pickup_loc_default, $post_id, 'pickup' );
						}
					?>
					
				</div>
			<?php } ?>


			<?php if( get_theme_mod( 'rd_bf_show_pickoff_loc', 'true' ) == 'true' ){ ?>
				<div class="col-md-3 rb_field">
					<label><?php esc_html_e( 'Drop-off Location', 'ireca' ); ?></label>
					<?php 
					
					if( $ovacrs_rental_type !== 'transportation' ) {
						echo ovacrs_get_locations_html( $class = 'ovacrs_pickoff_loc', $required = 'required', $selected = $drop_off_default, esc_html__( 'Select Location', 'ova-crs' ), $post_id ); 
					} else {
						echo ovacrs_get_locations_transport_html( $class = 'ovacrs_pickoff_loc', $required = 'required', $selected = $drop_off_default, $post_id, 'dropoff' );
					}
					?>
				</div>
			<?php } ?>
			
			<div class="col-md-3 rb_field">
				<?php 	$hour_default = get_theme_mod( 'rd_bf_hour_default', '09:00' ); 
						$time_step = get_theme_mod( 'rd_bf_time_step', '30' );
						$dateformat = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
						$timeformat = get_theme_mod( 'rd_bf_timeformat', 'H:i' );
						$ovacrs_unfixed_time = get_post_meta( $post_id, 'ovacrs_unfixed_time', true );

						$startdate_perido_time = '';

						if( ( $ovacrs_rental_type == 'period_time' ) ){
							$hour_default = '';
							$startdate_perido_time = 'startdate_perido_time';
							if( $ovacrs_unfixed_time != 'yes' ) {
								$timeformat = '';
							} 
							
						}
				?>
				<label>
					<?php esc_html_e( 'Pick-up Date', 'ireca' ); ?>
				</label>
				<div class="ovacrs_pickup_date"></div>
				<input type="text" 
						onkeydown="return false" 
						name="ovacrs_pickup_date" 
						data-hour_default="<?php echo esc_attr( $hour_default ); ?>" 
						data-time_step="<?php echo esc_attr( $time_step ); ?>"   
						data-dateformat="<?php echo esc_attr( $dateformat ); ?>" 
						data-timeformat="<?php echo esc_attr( $timeformat ); ?>" 
						class="required ovacrs_datetimepicker ovacrs_startdate <?php echo esc_attr($startdate_perido_time); ?>" 
						placeholder="<?php echo esc_attr( $dateformat ); ?>" 
						autocomplete="off" 
						value="<?php echo $start_time_default; ?>" 
						data-error=".ovacrs_pickup_date" 
						data-pid="<?php echo $post_id; ?>"
						onfocus="blur();" 
						data-lang="<?php echo esc_attr( $lang );?>" 
						data-time="<?php echo esc_attr( $cal_time ); ?>" 
						data-disweek="<?php echo esc_attr($calendar_dis_weekend); ?>"
						/>
			</div>

			<!-- Check Rental type -->
			<?php if( $ovacrs_rental_type == 'period_time'){ ?>

					<?php 
						$ovacrs_petime_id = get_post_meta( $post_id, 'ovacrs_petime_id', true );
						$ovacrs_petime_label = get_post_meta( $post_id, 'ovacrs_petime_label', true );
					?>
					<div class="col-md-3 rb_field">
						<label><?php esc_html_e( 'Choose Package', 'ireca' ); ?></label>
						<div class="period_package">

							<select name="ovacrs_period_package_id" class="required">
								<option value=""><?php esc_html_e( 'Select Package', 'ireca' ); ?></option>
								<?php if( $ovacrs_petime_id ){ foreach ($ovacrs_petime_id as $key => $value) { ?>
									<?php if( isset( $ovacrs_petime_id[$key] ) && isset( $ovacrs_petime_label[$key] ) ) ?>
									<option value="<?php echo esc_attr(trim( $ovacrs_petime_id[$key] ) ); ?>" > <?php echo esc_html( $ovacrs_petime_label[$key] ); ?> </option>
								<?php } } ?>
							</select>

						</div>
					</div>

			<?php }elseif( $ovacrs_rental_type !== 'transportation' ){ ?>

					<div class="col-md-3 rb_field">
						<label>
							<?php esc_html_e( 'Drop-off Date', 'ireca' ); ?>
						</label><div class="ovacrs_pickoff_date"></div>

						<input type="text" 
							name="ovacrs_pickoff_date" 
							onkeydown="return false"  
							data-hour_default="<?php echo esc_attr( $hour_default ); ?>" 
							data-time_step="<?php echo esc_attr( $time_step ); ?>" 
							data-dateformat="<?php echo esc_attr( $dateformat ); ?>" 
							data-timeformat="<?php echo esc_attr( $timeformat ); ?>" 
							class="required ovacrs_datetimepicker ovacrs_enddate" 
							placeholder="<?php echo esc_attr( $dateformat ); ?>"   
							autocomplete="off" 
							value="<?php echo $end_time_default; ?>" 
							data-error=".ovacrs_pickoff_date" onfocus="blur();" 
							data-lang="<?php echo esc_attr( $lang );?>" 
							data-time="<?php echo esc_attr( $cal_time ); ?>" 
							data-disweek="<?php echo esc_attr($calendar_dis_weekend); ?>"
						/>
					</div>

			<?php } ?>

			<?php if( get_theme_mod( 'rd_bf_show_quantity', 'true' ) == 'true' ){ ?>
				<div class="col-md-3 rb_field">
					<label><?php esc_html_e( 'Quantity', 'ireca' ); ?></label>
					<input type="number" name="ovacrs_quantity" value="1" min="1" max="<?php echo $inventory; ?>" />
				</div>
			<?php } ?>


			<?php

			$list_ckf_output = ovacrs_get_list_field_checkout( $post_id );
			
			if( is_array( $list_ckf_output ) && ! empty( $list_ckf_output ) ) {

				foreach( $list_ckf_output as $key => $field ) {

					if( array_key_exists('enabled', $field) &&  $field['enabled'] == 'on' ) {

						if( array_key_exists('required', $field) &&  $field['required'] == 'on' ) {
							$class_required = 'required';
						} else {
							$class_required = '';
						}

				?>
					<div class="col-md-3 rb_field">

						<label><?php echo esc_html( $field['label'] ); ?></label>
						<div class="ovacrs_<?php echo esc_attr( $key ) ?>"></div>
						<?php if( $field['type'] !== 'textarea' && $field['type'] !== 'select' ) { ?>
							<input type="<?php echo esc_attr( $field['type'] ) ?>" name="<?php echo esc_attr( $key ) ?>"  class=" <?php echo esc_attr( $field['class'] ) . ' ' . $class_required ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"   value="<?php echo $field['default']; ?>" data-error=".ovacrs_<?php echo esc_attr( $key ) ?>"  />
						<?php } ?>

						<?php if( $field['type'] === 'textarea' ) { ?>
							<textarea name="<?php echo esc_attr( $key ) ?>"  class=" <?php echo esc_attr( $field['class'] ) . ' ' . $class_required ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"   value="<?php echo $field['default']; ?>" cols="10" rows="5"></textarea>
						<?php } ?>

						<?php if( $field['type'] === 'select' ) { 

							$ova_options_key = $ova_options_text = [];
							if( array_key_exists( 'ova_options_key', $field ) ) {
								$ova_options_key = $field['ova_options_key'];
							}

							if( array_key_exists( 'ova_options_text', $field ) ) {
								$ova_options_text = $field['ova_options_text'];
							}
							

							?>
							<select name="<?php echo esc_attr( $key ) ?>"  class=" <?php echo esc_attr( $field['class'] ) . ' ' . $class_required ?>" >
								<?php 

								if( ! empty( $ova_options_text ) && is_array( $ova_options_text ) ) { 
									foreach( $ova_options_text as $key => $value ) { 
										$selected = '';
										if( $ova_options_key[$key] == $field['default'] ) {
											$selected = 'selected';
										}
										?>
										<option <?php echo  $selected ?> value="<?php echo esc_attr( $ova_options_key[$key] ) ?>"><?php echo esc_html( $value ) ?></option>
								<?php 

									} //end foreach
								}//end if
							?>
								
							</select>
						<?php } ?>

					</div>
				<?php
					}//endif
				}//end foreach
			}//end if

		?>

			

		</div>

		
		<?php 
			if( get_theme_mod( 'rd_bf_show_extra_resource', 'true' ) == 'true' ){
			$ovacrs_resource_name = get_post_meta( $post_id, 'ovacrs_resource_name', true ); 
			if( $ovacrs_resource_name ){

				$ovacrs_resource_price = get_post_meta( $post_id, 'ovacrs_resource_price', true ); 
				$ovacrs_resource_duration_val = get_post_meta( $post_id, 'ovacrs_resource_duration_val', true ); 
				$ovacrs_resource_duration_type = get_post_meta( $post_id, 'ovacrs_resource_duration_type', true ); 
				$ovacrs_resource_id = get_post_meta( $post_id, 'ovacrs_resource_id', true ); 
				$ovacrs_resource_desc = get_post_meta( $post_id, 'ovacrs_resource_desc', true ); 
		?>
			<div class="ireca_extra_service">
				<label><?php esc_html_e( 'Extra Service', 'ireca' ); ?></label>
						
					<div class="row ovacrs_resource">
						<?php foreach ($ovacrs_resource_name as $key => $value) { ?>
							<div class="wrap_item">
								<div class="item col-lg-4 col-md-6">
									
										<div class="left">
											<?php $ovacrs_resource_key = $ovacrs_resource_id[$key]; ?>
											<input type="checkbox" name="ovacrs_resource_checkboxs[<?php echo esc_attr( $ovacrs_resource_key ); ?>]" value="<?php echo esc_attr( $ovacrs_resource_name[$key] );  ?>" >
											<?php echo esc_html( $ovacrs_resource_name[$key] ); ?>
										</div>
										<div class="right">
											<div class="resource">
												<span class="dur_price"><?php echo wc_price( $ovacrs_resource_price[$key] ); ?></span>
												<span class="slash">/</span>
												<span class="dur_val"><?php if ( $ovacrs_resource_duration_val != '' )echo esc_html( $ovacrs_resource_duration_val[$key] ); ?></span>
												<span class="dur_type">
													<?php
														if( $ovacrs_resource_duration_type[$key] == 'hours' ){
															esc_html_e( 'Hour(s)', 'ireca' );
														}else if( $ovacrs_resource_duration_type[$key] == 'days' ){
															esc_html_e( 'Day(s)', 'ireca' );
														}if( $ovacrs_resource_duration_type[$key] == 'total' ){
															esc_html_e( 'Total', 'ireca' );
														}
													?>
												</span>
											</div>
										</div>
										
								
								</div>
								<?php if( isset( $ovacrs_resource_desc[$key] ) && $ovacrs_resource_desc[$key] ){ ?>
									<div class="desc">
										<?php echo do_shortcode( $ovacrs_resource_desc[$key] );?>
									</div>
								<?php } ?>
							</div>
						<?php } ?>
					</div>
			</div>
		<?php } } ?>

		
		<?php
			$deposit_enable = get_post_meta ( $post_id, 'ovacrs_enable_deposit', true );
			if ( $deposit_enable === 'yes' ) {
				wc_get_template_part( 'rental/deposit-form' );
			}
		?>

		<button type="submit" class="submit btn_tran"><?php esc_html_e( 'Booking', 'ireca' ); ?></button>

		<input type="hidden" name="ovacrs_rental_type" value="<?php echo esc_attr($ovacrs_rental_type); ?>" />

		<input type="hidden" name="car_id" value="<?php echo get_the_id(); ?>" />
		<?php $ovacrs_car_rental = 'ovacrs_car_rental'; ?>
		<input type="hidden" name="custom_product_type" value="<?php echo esc_attr( $ovacrs_car_rental ); ?>" />

		<input type="hidden" name="add-to-cart" value="<?php echo get_the_id(); ?>" />

		<input type="hidden" name="quantity" value="1" />

		

	</form>

</div>




