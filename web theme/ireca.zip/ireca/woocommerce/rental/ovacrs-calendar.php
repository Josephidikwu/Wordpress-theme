<?php if( get_theme_mod( 'rd_show_calendar', 'true' ) == 'true' ){

	$post_id = get_the_id();

	// Get array ID when use WPML
	$post_id_array = get_arr_product_ids( $post_id );
	
	$statuses = ovacrs_order_status();
	
	$order_date = get_order_rent_time( $post_id_array, $statuses );


	if( $order_date ){

			$script  = 'var order_time ='. $order_date .';';
			wp_add_inline_script('ireca', $script, 'before');
	} 



	$nav_month = get_theme_mod( 'rd_ca_nav_month', 'true' ) == 'true' ? 'month' : '';
	$nav_week = get_theme_mod( 'rd_ca_nav_week', 'true' ) == 'true' ? 'agendaWeek' : '';
	$nav_day = get_theme_mod( 'rd_ca_nav_day', 'true' ) == 'true' ? 'agendaDay' : '';
	$nav_list = get_theme_mod( 'rd_ca_nav_list', 'true' ) == 'true' ? 'listWeek' : '';
	$nav =  $nav_month.','.$nav_week.','.$nav_day.','.$nav_list;

	$default_view = ( get_theme_mod( 'rd_ca_default_view', 'month' ) != '' ) ? get_theme_mod( 'rd_ca_default_view', 'month' ) : 'month';

	$rd_ca_show_read_more_date = get_theme_mod( 'rd_ca_show_read_more_date', 'yes' ) == 'yes' ? 'show_read_more_date' : 'hide_read_more_date';
	?>

	
	<div id="calendar" class="<?php echo 'ireca__product_calendar '.$rd_ca_show_read_more_date; ?>" data-nav="<?php echo esc_attr( $nav ); ?>" data-default_view="<?php echo esc_attr( $default_view ); ?>" data-more_text="<?php esc_html_e( 'more', 'ireca' ); ?>" data-show_read_more_date="<?php echo $rd_ca_show_read_more_date; ?>">
	
		<ul class="intruction">
			<li>
				<span class="pink"></span>
				<span class="white"></span>
				<span><?php esc_html_e( 'Available','ireca' ) ?></span>		
			</li>
			
			<li>
				<span class="yellow"></span>
				<span><?php esc_html_e( 'Rent full day: No . Rent Hour: Yes','ireca' ) ?></span>		
			</li>
		</ul>

	</div>

<?php } ?>